"""
Generic plotting utilities for ALICE-style figures.
Designed for TH1D / TGraph / TGraphAsymmErrors.
"""

import os
import re
import zipfile
import ROOT
from ROOT import TFile, TColor, TGaxis, gStyle, gROOT


# ------------------------------------------------------------------
# ROOT constant parsing
# ------------------------------------------------------------------
def get_root_constant(name):
    if not isinstance(name, str):
        return name

    match = re.match(r'^([a-zA-Z_][a-zA-Z0-9_]*)([+\-*/%].*)?$', name.strip())
    if not match:
        raise ValueError(f"Invalid ROOT constant format: {name}")

    const_name, expr = match.groups()
    base_val = getattr(ROOT, const_name)
    return base_val if not expr else eval(f"{base_val}{expr}", {}, {})


# ------------------------------------------------------------------
# Marker helpers
# ------------------------------------------------------------------
def get_empty_marker_style(marker_style):
    mapping = {
        ROOT.kFullCircle: ROOT.kOpenCircle,
        ROOT.kFullSquare: ROOT.kOpenSquare,
        ROOT.kFullTriangleUp: ROOT.kOpenTriangleUp,
        ROOT.kFullTriangleDown: ROOT.kOpenTriangleDown,
        ROOT.kFullDiamond: ROOT.kOpenDiamond,
        ROOT.kFullCross: ROOT.kOpenCross,
        ROOT.kFullStar: ROOT.kOpenStar,
        ROOT.kFullCrossX: ROOT.kOpenCrossX,
        ROOT.kFullDoubleDiamond: ROOT.kOpenDoubleDiamond,
    }
    return mapping.get(marker_style, ROOT.kOpenCircle)


def create_legend_clone(h):
    clone = h.Clone(h.GetName() + '_leg')
    clone.SetTitle('')
    clone.SetLineColor(0)
    clone.SetLineWidth(0)
    clone.SetFillStyle(0)
    return clone


def create_empty_clone(h, markersize_scale=1.0):
    clone = h.Clone(h.GetName() + '_empty')
    clone.SetTitle('')
    clone.SetMarkerStyle(get_empty_marker_style(h.GetMarkerStyle()))
    clone.SetMarkerColor(ROOT.kBlack)
    clone.SetMarkerSize(h.GetMarkerSize() * markersize_scale)
    clone.SetLineColor(0)
    clone.SetLineWidth(0)
    clone.SetFillStyle(0)
    return clone


def DrawMarkerWithBlackOutline(h, drawopt='E',
                                color=ROOT.kRed,
                                markerstyle=ROOT.kFullCircle,
                                markersize=1.2,
                                outline_scale=1.4):
    h_outline = h.Clone(h.GetName() + '_outline')
    h_outline.SetMarkerStyle(get_empty_marker_style(markerstyle))
    h_outline.SetMarkerSize(markersize * outline_scale)
    h_outline.SetMarkerColor(ROOT.kBlack)
    h_outline.SetLineColor(0)

    h_fill = h.Clone(h.GetName() + '_fill')
    h_fill.SetMarkerStyle(markerstyle)
    h_fill.SetMarkerSize(markersize)
    h_fill.SetMarkerColor(color)
    h_fill.SetLineColor(0)

    h_outline.Draw(f'{drawopt} same')
    h_fill.Draw(f'{drawopt} same')


# ------------------------------------------------------------------
# Global style
# ------------------------------------------------------------------
def SetGlobalStyle(**kwargs):
    gStyle.SetPadRightMargin(kwargs.get('padrightmargin', 0.04))
    gStyle.SetPadLeftMargin(kwargs.get('padleftmargin', 0.1))
    gStyle.SetPadTopMargin(kwargs.get('padtopmargin', 0.06))
    gStyle.SetPadBottomMargin(kwargs.get('padbottommargin', 0.12))

    gStyle.SetTitleSize(kwargs.get('titlesize', 0.05), 'xyz')
    gStyle.SetLabelSize(kwargs.get('labelsize', 0.045), 'xyz')
    gStyle.SetTitleOffset(kwargs.get('titleoffset', 1.2), 'xyz')
    gStyle.SetOptTitle(kwargs.get('opttitle', 0))
    gStyle.SetOptStat(kwargs.get('optstat', 0))
    gStyle.SetPadTickX(1)
    gStyle.SetPadTickY(1)
    gStyle.SetLegendBorderSize(0)

    # Strip trailing zeros in axis labels (0.040 -> 0.04)
    gStyle.SetStripDecimals(True)

    if 'maxdigits' in kwargs:
        TGaxis.SetMaxDigits(kwargs['maxdigits'])
    if 'palette' in kwargs:
        gStyle.SetPalette(kwargs['palette'])

    gROOT.ForceStyle()


def SetObjectStyle(obj, **kwargs):
    lalpha = kwargs.get('linealpha', 1)
    malpha = kwargs.get('markeralpha', 1)
    falpha = kwargs.get('fillalpha', 1)

    if 'alpha' in kwargs:
        lalpha = malpha = falpha = kwargs['alpha']

    if 'linecolor' in kwargs:
        c = get_root_constant(kwargs['linecolor']) if isinstance(kwargs['linecolor'], str) else kwargs['linecolor']
        obj.SetLineColorAlpha(c, lalpha) if lalpha < 1 else obj.SetLineColor(c)
    if 'linewidth' in kwargs:
        obj.SetLineWidth(kwargs['linewidth'])
    if 'linestyle' in kwargs:
        obj.SetLineStyle(kwargs['linestyle'])

    if 'markercolor' in kwargs:
        c = get_root_constant(kwargs['markercolor']) if isinstance(kwargs['markercolor'], str) else kwargs['markercolor']
        obj.SetMarkerColorAlpha(c, malpha) if malpha < 1 else obj.SetMarkerColor(c)
    if 'markersize' in kwargs:
        obj.SetMarkerSize(kwargs['markersize'])
    if 'markerstyle' in kwargs:
        obj.SetMarkerStyle(get_root_constant(kwargs['markerstyle']))

    if 'fillcolor' in kwargs:
        c = get_root_constant(kwargs['fillcolor']) if isinstance(kwargs['fillcolor'], str) else kwargs['fillcolor']
        obj.SetFillColorAlpha(c, falpha) if falpha < 1 else obj.SetFillColor(c)
    if 'fillstyle' in kwargs:
        obj.SetFillStyle(kwargs['fillstyle'])

    if 'color' in kwargs:
        c = get_root_constant(kwargs['color']) if isinstance(kwargs['color'], str) else kwargs['color']
        obj.SetLineColorAlpha(c, lalpha) if lalpha < 1 else obj.SetLineColor(c)
        obj.SetMarkerColorAlpha(c, malpha) if malpha < 1 else obj.SetMarkerColor(c)
        obj.SetFillColorAlpha(c, falpha) if falpha < 1 else obj.SetFillColor(c)


# ------------------------------------------------------------------
# Object loading
# ------------------------------------------------------------------
def LoadObjectFromFile(path_to_file, object_name):
    infile = TFile.Open(path_to_file)
    if not infile or infile.IsZombie():
        raise RuntimeError(f"Cannot open file: {path_to_file}")

    obj = infile.Get(object_name)
    if not obj:
        raise RuntimeError(f"Cannot find object '{object_name}' in {path_to_file}")

    obj.SetDirectory(0)
    return obj, infile


def ApplyStyleToHist(h, style):
    if 'linecolor' in style:
        h.SetLineColor(get_root_constant(style['linecolor']))
    if 'markercolor' in style:
        h.SetMarkerColor(get_root_constant(style['markercolor']))
    if 'markerstyle' in style:
        h.SetMarkerStyle(get_root_constant(style['markerstyle']))
    if 'markersize' in style:
        h.SetMarkerSize(style['markersize'])
    if 'linewidth' in style:
        h.SetLineWidth(style['linewidth'])
    if 'linestyle' in style:
        h.SetLineStyle(style['linestyle'])


# ------------------------------------------------------------------
# Canvas helpers
# ------------------------------------------------------------------
def GetCanvas(name, axisname, xmin=0.4, xmax=40, ymin=-0.20, ymax=0.62,
              setlogx=False, setlogy=False, width=1600, height=1600):
    canv = ROOT.TCanvas(name, name, width, height)
    if setlogx:
        canv.SetLogx()
    if setlogy:
        canv.SetLogy()

    hframe = canv.DrawFrame(xmin, ymin, xmax, ymax, axisname)
   
    hframe.GetYaxis().SetTitleOffset(1.6)
    hframe.GetXaxis().SetTitleOffset(1.0)
    hframe.GetXaxis().SetMoreLogLabels()
    return canv, hframe


def GetLegend(xmin=0.19, ymin=0.62, xmax=0.75, ymax=0.77,
              textsize=0.04, ncolumns=1, header=' ', fillstyle=0):
    if textsize is None:
        textsize = 0.04
    if ncolumns is None:
        ncolumns = 1
    if header is None:
        header = ' '
    leg = ROOT.TLegend(xmin, ymin, xmax, ymax)
    leg.SetTextSize(textsize)
    leg.SetNColumns(ncolumns)
    leg.SetFillStyle(fillstyle)
    leg.SetHeader(header)
    return leg


def DrawLineAt0(min_x, max_x):
    line = ROOT.TLine(min_x, 0, max_x, 0)
    line.SetLineStyle(9)
    line.SetLineWidth(2)
    line.SetLineColor(ROOT.kGray + 2)
    return line


# ------------------------------------------------------------------
# Automatic y-range
# ------------------------------------------------------------------
def AutoYRange(h, scale=1.3):
    ymax = 0.0
    for i in range(1, h.GetNbinsX() + 1):
        ymax = max(ymax, h.GetBinContent(i) + h.GetBinError(i))
    return 0.0, ymax * scale


def AutoYRangeWithSyst(h, syst_dict, scale=1.3):
    ymax = 0.0
    for i in range(1, h.GetNbinsX() + 1):
        syst = syst_dict.get(i, 0.0)
        ymax = max(ymax, h.GetBinContent(i) + syst)
    return 0.0, ymax * scale


# ------------------------------------------------------------------
# Saving
# ------------------------------------------------------------------
def SaveCanvas(canv, title, suffix='', formats=('pdf',)):
    for form in formats:
        canv.SaveAs(f'{title}{suffix}.{form}')


# ------------------------------------------------------------------
# Systematic uncertainty helpers
# ------------------------------------------------------------------
def LoadSystFromTH1(path_to_file, object_name):
    """
    Load a TH1D containing absolute systematic uncertainties.
    Returns a dict {bin_index (1-based): syst_value}.
    """
    infile = ROOT.TFile.Open(path_to_file, 'READ')
    if not infile or infile.IsZombie():
        raise RuntimeError(f"Cannot open {path_to_file}")

    h = infile.Get(object_name)
    if not h:
        raise RuntimeError(f"Cannot find {object_name} in {path_to_file}")

    h = h.Clone(h.GetName() + '_copy_' + str(id(h)))
    h.SetDirectory(0)
    infile.Close()

    syst = {}
    for i in range(1, h.GetNbinsX() + 1):
        syst[i] = h.GetBinContent(i)
    return syst


import array

def MakeSystBoxFromTH1(h_nominal, syst_dict):
    """
    Create a NEW TH1D with the SAME (non-uniform) binning as h_nominal,
    and with bin errors equal to the syst values.
    Horizontal box width = bin width (default TH1 behaviour).
    """
    n_bins = h_nominal.GetNbinsX()

    xbins = array.array('d', [0.0] * (n_bins + 1))
    for i in range(1, n_bins + 2):
        xbins[i - 1] = h_nominal.GetXaxis().GetBinLowEdge(i)

    h_box = ROOT.TH1D(
        h_nominal.GetName() + '_syst_' + str(id(h_nominal)),
        h_nominal.GetTitle(),
        n_bins,
        xbins
    )
    h_box.SetDirectory(0)

    for i in range(1, n_bins + 1):
        h_box.SetBinContent(i, h_nominal.GetBinContent(i))
        h_box.SetBinError(i, syst_dict.get(i, 0.0))

    return h_box


def MakeSystBoxFixedWidth(h_nominal, syst_dict, half_width=0.05):
    """
    Create a TGraphAsymmErrors that represents the systematic uncertainty
    box, with a FIXED horizontal half-width for every point.

    Parameters
    ----------
    h_nominal : TH1D
        Nominal histogram. Its bin centers give the x positions, its bin
        contents give the y positions.
    syst_dict : dict
        {bin_index (1-based): syst_value}
    half_width : float
        Half of the fixed horizontal box width. Total width = 2*half_width.

    Returns
    -------
    TGraphAsymmErrors
    """
    n_bins = h_nominal.GetNbinsX()

    g = ROOT.TGraphAsymmErrors(n_bins)

    for i in range(1, n_bins + 1):
        x = h_nominal.GetXaxis().GetBinCenter(i)
        y = h_nominal.GetBinContent(i)
        ey = syst_dict.get(i, 0.0)

        g.SetPoint(i - 1, x, y)
        g.SetPointEXlow(i - 1,  half_width)
        g.SetPointEXhigh(i - 1, half_width)
        g.SetPointEYlow(i - 1,  ey)
        g.SetPointEYhigh(i - 1, ey)

    g.SetFillStyle(0)
    g.SetMarkerSize(0)

    return g