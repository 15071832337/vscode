"""
Main script: produce figures from YAML config.
"""

import os
import zipfile
import yaml
import ROOT
from ROOT import TLatex

from plot_utils import (
    SetGlobalStyle, LoadObjectFromFile, ApplyStyleToHist,
    GetCanvas, GetLegend, DrawLineAt0, AutoYRange, AutoYRangeWithSyst,
    SaveCanvas, create_legend_clone, create_empty_clone,
    DrawMarkerWithBlackOutline, get_root_constant,
    LoadSystFromTH1, MakeSystBoxFixedWidth
)


# ------------------------------------------------------------------
# 1. Read YAML config
# ------------------------------------------------------------------
CONFIG_FILE = 'config_figures.yml'
with open(CONFIG_FILE, 'r') as f:
    config = yaml.safe_load(f)

outdir = config.get('outdir', './figures/')
os.makedirs(outdir, exist_ok=True)
suffix = config.get('suffix', '')
formats = config.get('output_formats', ['pdf'])


# ------------------------------------------------------------------
# 2. Global style
# ------------------------------------------------------------------
SetGlobalStyle(**config.get('global_style', {}))

latex = TLatex()
latex.SetNDC()
latex.SetTextFont(42)


# ------------------------------------------------------------------
# 3. Helper: draw a single TH1D from config
# ------------------------------------------------------------------

# Final pass: enforce tick-label and legend size, including nested inset pads.
def enforce_tick_and_legend_sizes(canvas):
    def visit(pad):
        pad.cd()
        for obj in list(pad.GetListOfPrimitives()):
            if obj.InheritsFrom('TPad'):
                visit(obj)
                pad.cd()
            elif obj.InheritsFrom('TLegend'):
                obj.SetTextFont(42)
                obj.SetTextSize(0.045)
                for entry in obj.GetListOfPrimitives():
                    entry.SetTextFont(42)
                    entry.SetTextSize(0.045)
            elif obj.InheritsFrom('TH1') or obj.InheritsFrom('TGraph'):
                for axis in (obj.GetXaxis(), obj.GetYaxis()):
                    axis.SetLabelFont(42)
                    axis.SetLabelSize(0.045)
        pad.Modified()
        pad.Update()
    visit(canvas)
    canvas.cd()


def review_physics_text(text):
    # Also normalize titles stored inside the input ROOT objects.
    for old, new in [('cos(#it{#theta}^{*})', 'cos(#it{#theta}^{*})'),
                     ('#DeltaR', '#Delta#it{R}'),
                     ('#Delta#eta', '#Delta#it{#eta}'),
                     ('#Delta#phi', '#Delta#it{#phi}'),
                     ('|y|', '|#it{y}|'),
                     ('m_{#Lambda', '#it{m}_{#Lambda'),
                     ('N_{pairs}', '#it{N}_{pairs}'),
                     ('<p_{T,#Lambda}>', '#langle#it{p}_{T,#Lambda}#rangle')]:
        text = text.replace(old, new)
    return text

def apply_review_layout(canvas, style):
    def visit(pad):
        pad.cd()
        for obj in list(pad.GetListOfPrimitives()):
            if obj.InheritsFrom('TPad'):
                visit(obj)
                pad.cd()
            elif obj.InheritsFrom('TLatex'):
                obj.SetTitle(review_physics_text(obj.GetTitle()))
            elif obj.InheritsFrom('TLegend'):
                size = style.get('review_legend_size', 0.045)
                obj.SetTextFont(42)
                obj.SetTextSize(size)
                for entry in obj.GetListOfPrimitives():
                    entry.SetTextFont(42)
                    entry.SetTextSize(size)
            elif obj.InheritsFrom('TH1') or obj.InheritsFrom('TGraph'):
                for axis in (obj.GetXaxis(), obj.GetYaxis()):
                    axis.SetTitle(review_physics_text(axis.GetTitle()))
                    axis.SetLabelSize(style.get('review_label_size', 0.045))
                if obj.InheritsFrom('TH2'):
                    obj.GetXaxis().SetNdivisions(505)
                    obj.GetYaxis().SetNdivisions(505)
                    obj.GetXaxis().SetLabelOffset(0.018)
                    obj.GetYaxis().SetLabelOffset(0.018)
                    # Suppress only the first y tick label at the common origin.
                    obj.GetYaxis().ChangeLabel(1, -1, 0)
                    obj.GetZaxis().SetLabelSize(style.get('review_label_size', 0.032))
                    obj.GetXaxis().SetTitleOffset(1.5)
                    obj.GetYaxis().SetTitleOffset(1.8)
        pad.Modified()
        pad.Update()
    visit(canvas)
    canvas.cd()


def apply_second_review(canvas, style):
    keep = []
    def visit(pad):
        pad.cd()
        for obj in list(pad.GetListOfPrimitives()):
            if obj.InheritsFrom('TPad'):
                visit(obj)
                pad.cd()
            elif obj.InheritsFrom('TH1') or obj.InheritsFrom('TGraph'):
                if pad.GetName().startswith('zoom_'):
                    for ax in (obj.GetXaxis(), obj.GetYaxis()):
                        ax.SetLabelSize(style.get('inset', {}).get('labelsize', 0.055))
                        ax.SetTitleSize(style.get('inset', {}).get('titlesize', 0.045))
                if style.get('candidate_mass_axes', False):
                    obj.GetXaxis().SetTitle(style['candidate_xtitle'])
                    obj.GetXaxis().SetNdivisions(505)
                    if obj.InheritsFrom('TH2'):
                        obj.GetYaxis().SetTitle(style['candidate_ytitle'])
                    else:
                        obj.GetYaxis().SetTitle('Counts')
                elif style.get('axisname'):
                    parts = style['axisname'].split(';')
                    if len(parts) >= 3:
                        obj.GetXaxis().SetTitle(parts[1])
                        obj.GetYaxis().SetTitle(parts[2])
            elif obj.InheritsFrom('TLegend'):
                for entry in obj.GetListOfPrimitives():
                    label = entry.GetLabel()
                    if style.get('candidate_mass_axes', False) and label != 'Data':
                        source = entry.GetObject()
                        if source:
                            proxy = ROOT.TGraph(1)
                            proxy.SetLineColor(source.GetLineColor())
                            proxy.SetLineStyle(source.GetLineStyle())
                            proxy.SetLineWidth(3)
                            entry.SetObject(proxy)
                            keep.append(proxy)
                    if style.get('legend_without_caps', False):
                        # TLegend: option E omits end caps; L+E requests them.
                        entry.SetOption('pe')
        pad.Modified()
        pad.Update()
    visit(canvas)
    canvas._second_review_refs = keep
    canvas.cd()

def draw_abcd_2d(key, style_key):
    if not config.get(f'plot_{key}', False):
        return
    style = config[style_key]
    inp = config['input'][key]
    source = ROOT.TFile.Open(inp['file'], 'READ')
    if not source or source.IsZombie():
        raise RuntimeError(f"Cannot open ABCD input: {inp['file']}")
    hist = None
    overlays = []
    try:
        original = source.Get(inp.get('object', 'cABCD_SE_R0_c01'))
        if not original or not original.InheritsFrom('TCanvas'):
            raise RuntimeError(f"Missing TCanvas: {inp.get('object')}")
        wanted = inp.get('histogram', 'h2ABCD_SE_R0_c01')
        candidates = []

        def scan(pad):
            for obj in pad.GetListOfPrimitives():
                if obj.InheritsFrom('TH2'):
                    candidates.append(obj)
                elif obj.InheritsFrom('TPad'):
                    scan(obj)
                elif obj.InheritsFrom('TLine'):
                    overlays.append(obj.Clone())

        scan(original)
        matches = [obj for obj in candidates if obj.GetName() == wanted]
        if not matches and len(candidates) != 1:
            raise RuntimeError(f"Cannot uniquely select TH2 {wanted}; found "
                               f"{[obj.GetName() for obj in candidates]}")
        selected = matches[0] if matches else candidates[0]
        hist = selected.Clone(f'{key}_distribution')
        hist.SetDirectory(0)
    finally:
        source.Close()

    c = ROOT.TCanvas(f'c_{key}', '', 1300, 1250)
    c.SetFillColor(ROOT.kWhite)

    # 顶部留白加大：把图的 top margin 调大，给 latex 文字腾空间
    top_margin = style.get('top_margin', 0.28)
    c.SetLeftMargin(0.18)
    c.SetRightMargin(style.get('right_margin', 0.12))   # ← 右边留白加大
    c.SetBottomMargin(0.15)
    c.SetTopMargin(top_margin)
    c.SetTicks(1, 1)
    c.SetLogz(style.get('setlogz', False))

    hist.SetStats(0)
    hist.SetTitle('')
    hist.GetXaxis().SetTitle(style.get('xtitle', '#it{M}_{p#pi^{-}} (GeV/#it{c}^{2})'))
    hist.GetYaxis().SetTitle(style.get('ytitle', '#it{M}_{#bar{p}#pi^{+}} (GeV/#it{c}^{2})'))
    # 不显示 z 轴（色标）标题
    hist.GetZaxis().SetTitle('')

    # 刻度字号调小（可从 YAML 用 label_size 覆盖）
    label_size = style.get('label_size', 0.035)
    title_size = style.get('title_size', 0.045)

    for axis in (hist.GetXaxis(), hist.GetYaxis()):
        axis.SetLabelFont(42)
        axis.SetLabelSize(label_size)     # ← 刻度字号变小
        axis.SetTitleFont(42)
        axis.SetTitleSize(title_size)

    hist.GetXaxis().SetTitleOffset(1.35)
    hist.GetYaxis().SetTitleOffset(0.95)

    for axis, lo, hi in ((hist.GetXaxis(), 'xmin', 'xmax'),
                         (hist.GetYaxis(), 'ymin', 'ymax')):
        if lo in style and hi in style:
            axis.SetRangeUser(style[lo], style[hi])

    # 用 'COL' 画颜色，不画 z 轴和色标
    hist.Draw('COL')
    keep = [hist]

    # ---- region lines ----
    if style.get('draw_regions', True):
        for line in overlays:
            line.Draw('SAME')
        keep.extend(overlays)

    # ---- latex：画在顶部留白区（黑色字，pad 内 NDC）----
    # y 坐标 > 1.0 表示落在 top margin 区域
    latex.SetNDC()
    latex.SetTextColor(ROOT.kBlack)
    latex.SetTextAlign(12)
    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])
    latex.SetTextAlign(11)   # 恢复默认

    c.Modified()
    c.Update()

    # enforce 会把 axis label size 强制成 0.045，这里再设回 label_size
    enforce_tick_and_legend_sizes(c)
    for obj in c.GetListOfPrimitives():
        if obj.InheritsFrom('TH2'):
            for ax in (obj.GetXaxis(), obj.GetYaxis()):
                ax.SetLabelSize(label_size)
                ax.SetLabelFont(42)
    c.Modified()
    c.Update()

    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}; extracted TH2 from {inp['object']}")


def draw_th1d(key, style_key):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]
    inp = config['input'][key]

    h, infile = LoadObjectFromFile(inp['file'], inp['object'])
    if not h:
        raise RuntimeError(f"Cannot load {key}")

    ApplyStyleToHist(h, style)

    syst_file = style.get('syst_file', None)
    syst_object = style.get('syst_object', None)
    syst_dict = None
    if syst_file and syst_object:
        syst_dict = LoadSystFromTH1(syst_file, syst_object)

    if not h.GetXaxis().GetTitle() or not h.GetYaxis().GetTitle():
        parts = style.get('axisname', ';;').split(';')
        if len(parts) >= 2 and not h.GetXaxis().GetTitle():
            h.GetXaxis().SetTitle(parts[1])
        if len(parts) >= 3 and not h.GetYaxis().GetTitle():
            h.GetYaxis().SetTitle(parts[2])

    xmin = style.get('xmin', h.GetXaxis().GetXmin())
    xmax = style.get('xmax', h.GetXaxis().GetXmax())
    ymin = style.get('ymin', 0.0)
    ymax = style.get('ymax', -1)

    if ymax < 0:
        if syst_dict:
            ymin, ymax = AutoYRangeWithSyst(h, syst_dict, scale=style.get('yrange_scale', 1.3))
        else:
            ymin, ymax = AutoYRange(h, scale=style.get('yrange_scale', 1.3))

    h.GetXaxis().SetRangeUser(xmin, xmax)
    h.GetYaxis().SetRangeUser(ymin, ymax)

    c, hframe = GetCanvas(
        f'c_{key}', style.get('axisname', ';;'),
        xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax,
        setlogx=style.get('setlogx', False),
        setlogy=style.get('setlogy', False)
    )

    # --- axis title offset (from global_style, overridable per-style) ---
    gs = config.get('global_style', {})
    x_title_offset = style.get('x_title_offset', 1.2)
    y_title_offset = style.get('y_title_offset', 2.0)
    hframe.GetXaxis().SetTitleOffset(x_title_offset)
    hframe.GetYaxis().SetTitleOffset(y_title_offset)

    drawopt = style.get('drawopt', 'E')
    black_outline = style.get('black_outline', False)
    outline_scale = style.get('outline_scale', 1.4)

    half_width = style.get('syst_half_width', 0.05)

    # --- syst box first ---
    if syst_dict:
        box = MakeSystBoxFixedWidth(h, syst_dict, half_width=half_width)
        box.SetFillStyle(0)
        box.SetLineColor(h.GetMarkerColor())
        box.SetLineWidth(style.get('syst_linewidth', 2))
        box.SetMarkerSize(0)
        box.Draw('E2 same')

    # --- data points ---
    if black_outline:
        DrawMarkerWithBlackOutline(
            h, drawopt=drawopt,
            color=h.GetMarkerColor(),
            markerstyle=h.GetMarkerStyle(),
            markersize=h.GetMarkerSize(),
            outline_scale=outline_scale
        )
    else:
        h.Draw(f'{drawopt} same')

    # --- dashed y = 0 reference line ---
    if style.get('draw_zero_line', False):
        line = ROOT.TLine(xmin, style.get('zero_line_y', 0.0),
                          xmax, style.get('zero_line_y', 0.0))
        line.SetLineStyle(style.get('zero_line_style', 2))       # 2 = dashed
        line.SetLineColor(get_root_constant(style.get('zero_line_color', 'kGray+1')))
        line.SetLineWidth(style.get('zero_line_width', 2))
        line.Draw('SAME')

    if style.get('legend'):
        lg = style['legend']
        leg = GetLegend(
            xmin=lg.get('xmin', 0.55),
            ymin=lg.get('ymin', 0.70),
            xmax=lg.get('xmax', 0.85),
            ymax=lg.get('ymax', 0.80),
            textsize=0.045,
            ncolumns=lg.get('ncolumns', 1),
            header=lg.get('header', '')
        )
        for entry in lg.get('entries', []):
            obj_name, label, opt = entry[0], entry[1], entry[2]
            if obj_name == 0:
                leg.AddEntry(0, label, '')
            elif obj_name == 'self':
                if black_outline:
                    h_leg = create_empty_clone(h, markersize_scale=1.2)
                else:
                    h_leg = create_legend_clone(h)
                leg.AddEntry(h_leg, label, opt)
            else:
                leg.AddEntry(0, label, '')
        leg.Draw('same')

    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")


def draw_thSEandME(key, style_key):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]
    inp = config['input'][key]

    h, infile = LoadObjectFromFile(inp['file'], inp['object'])
    if not h:
        raise RuntimeError(f"Cannot load {key}")

    ApplyStyleToHist(h, style)

    syst_file = style.get('syst_file', None)
    syst_object = style.get('syst_object', None)
    syst_dict = None
    if syst_file and syst_object:
        syst_dict = LoadSystFromTH1(syst_file, syst_object)

    if not h.GetXaxis().GetTitle() or not h.GetYaxis().GetTitle():
        parts = style.get('axisname', ';;').split(';')
        if len(parts) >= 2 and not h.GetXaxis().GetTitle():
            h.GetXaxis().SetTitle(parts[1])
        if len(parts) >= 3 and not h.GetYaxis().GetTitle():
            h.GetYaxis().SetTitle(parts[2])

    xmin = style.get('xmin', h.GetXaxis().GetXmin())
    xmax = style.get('xmax', h.GetXaxis().GetXmax())
   

    ymin = style.get('ymin', None)
    ymax = style.get('ymax', -1)

    if ymax < 0:
        if syst_dict:
            ymin_auto, ymax_auto = AutoYRangeWithSyst(h, syst_dict, scale=style.get('yrange_scale', 1.3))
        else:
            ymin_auto, ymax_auto = AutoYRange(h, scale=style.get('yrange_scale', 1.3))
        ymax = ymax_auto
        if ymin is None:
            ymin = ymin_auto

    if ymin is None:
        ymin = 0.0

    h.GetXaxis().SetRangeUser(xmin, xmax)
    h.GetYaxis().SetRangeUser(ymin, ymax)

    c, hframe = GetCanvas(
        f'c_{key}', style.get('axisname', ';;'),
        xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax,
        setlogx=style.get('setlogx', False),
        setlogy=style.get('setlogy', False)
    )

    # ↓↓↓ 设在 hframe 上，而不是 h 上
    n_div_x = style.get('ndiv_x', 4)
    n_div_y = style.get('ndiv_y', 4)
    hframe.GetXaxis().SetNdivisions(n_div_x, False)
    hframe.GetYaxis().SetNdivisions(n_div_y, False)
    hframe.GetYaxis().SetNoExponent(False)
    hframe.GetYaxis().SetMaxDigits(2)

    drawopt = style.get('drawopt', 'E')
    black_outline = style.get('black_outline', False)
    outline_scale = style.get('outline_scale', 1.4)

    half_width = style.get('syst_half_width', 0.05)

    # --- syst box first ---
    if syst_dict:
        box = MakeSystBoxFixedWidth(h, syst_dict, half_width=half_width)
        box.SetFillStyle(0)
        box.SetLineColor(h.GetMarkerColor())
        box.SetLineWidth(style.get('syst_linewidth', 2))
        box.SetMarkerSize(0)
        box.Draw('E2 same')

    # --- data points ---
    if black_outline:
        DrawMarkerWithBlackOutline(
            h, drawopt=drawopt,
            color=h.GetMarkerColor(),
            markerstyle=h.GetMarkerStyle(),
            markersize=h.GetMarkerSize(),
            outline_scale=outline_scale
        )
    else:
        h.Draw(f'{drawopt} same')

    if style.get('draw_zero_line', False):
        DrawLineAt0(xmin, xmax).Draw('same')

    if style.get('legend'):
        lg = style['legend']
        leg = GetLegend(
            xmin=lg.get('xmin', 0.55),
            ymin=lg.get('ymin', 0.70),
            xmax=lg.get('xmax', 0.85),
            ymax=lg.get('ymax', 0.80),
            textsize=0.045,
            ncolumns=lg.get('ncolumns', 1),
            header=lg.get('header', '')
        )
        for entry in lg.get('entries', []):
            obj_name, label, opt = entry[0], entry[1], entry[2]
            if obj_name == 0:
                leg.AddEntry(0, label, '')
            elif obj_name == 'self':
                if black_outline:
                    h_leg = create_empty_clone(h, markersize_scale=1.2)
                else:
                    h_leg = create_legend_clone(h)
                leg.AddEntry(h_leg, label, opt)
            else:
                leg.AddEntry(0, label, '')
        leg.Draw('same')

    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")

def draw_ratio_with_fit(key, style_key):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]
    inp = config['input'][key]

    # ---- 读 ratio 数据 ----
    h, infile = LoadObjectFromFile(inp['file'], inp['object'])
    if not h:
        raise RuntimeError(f"Cannot load {key}")

    ApplyStyleToHist(h, style)

    if not h.GetXaxis().GetTitle() or not h.GetYaxis().GetTitle():
        parts = style.get('axisname', ';;').split(';')
        if len(parts) >= 2 and not h.GetXaxis().GetTitle():
            h.GetXaxis().SetTitle(parts[1])
        if len(parts) >= 3 and not h.GetYaxis().GetTitle():
            h.GetYaxis().SetTitle(parts[2])

    xmin = style.get('xmin', h.GetXaxis().GetXmin())
    xmax = style.get('xmax', h.GetXaxis().GetXmax())
    ymin = style.get('ymin', None)
    ymax = style.get('ymax', -1)

    if ymax < 0:
        ymin_auto, ymax_auto = AutoYRange(h, scale=style.get('yrange_scale', 1.3))
        ymax = ymax_auto
        if ymin is None:
            ymin = ymin_auto

    if ymin is None:
        ymin = 0.0

    h.GetXaxis().SetRangeUser(xmin, xmax)
    h.GetYaxis().SetRangeUser(ymin, ymax)

    c, hframe = GetCanvas(
        f'c_{key}', style.get('axisname', ';;'),
        xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax,
        setlogx=style.get('setlogx', False),
        setlogy=style.get('setlogy', False)
    )

    n_div_x = style.get('ndiv_x', 4)
    n_div_y = style.get('ndiv_y', 4)
    hframe.GetXaxis().SetNdivisions(n_div_x, False)
    hframe.GetYaxis().SetNdivisions(n_div_y, False)
    hframe.GetYaxis().SetNoExponent(False)
    hframe.GetYaxis().SetMaxDigits(2)

    hframe.GetYaxis().SetRangeUser(ymin, ymax)
    c.cd()
    hframe.Draw('AXIS')

    # ---- 数据点 ----
    drawopt = style.get('drawopt', 'E')
    h.GetYaxis().SetRangeUser(ymin, ymax)
    h.Draw(f'{drawopt} same')

    # ---- 现场拟合（与 SS 一致，范围 -1..1）----
    fit_xmin = style.get('fit_xmin', -1.0)
    fit_xmax = style.get('fit_xmax',  1.0)
    cscale   = style.get('cscale', -0.565479)   # alpha1 * alpha2

    fit_func = ROOT.TF1(f'tf1_fit_US_{key}', '1.0 + [0]*x', fit_xmin, fit_xmax)
    fit_func.SetParameter(0, 0.0)
    fit_func.SetParLimits(0, -1.0, 1.0)
    fit_func.SetLineColor(get_root_constant(style.get('fit_color', 'kRed')))
    fit_func.SetLineWidth(style.get('fit_linewidth', 3))
    fit_func.SetLineStyle(style.get('fit_linestyle', 1))

    fit_status = h.Fit(fit_func, 'EIRMBS', '', fit_xmin, fit_xmax)

    cp     = fit_func.GetParameter(0)
    cp_err = fit_func.GetParError(0)
    ndf    = fit_func.GetNDF()
    chi2   = fit_func.GetChisquare()
    chi2ndf = (chi2 / ndf) if ndf > 0 else 0.0

    if cscale != 0.0:
        P     = cp / cscale
        P_err = cp_err / abs(cscale)
    else:
        P, P_err = 0.0, 0.0

    print(f"[US ratio fit] key={key} status={fit_status} CP={cp:.5f}±{cp_err:.5f} "
          f"chi2/ndf={chi2:.2f}/{ndf}={chi2ndf:.3f} P={P:.4f}±{P_err:.4f}")

    fit_func.Draw('SAME')

    # ---- 零线 / 参考线 ----
    if style.get('draw_zero_line', False):
        DrawLineAt0(xmin, xmax).Draw('same')

    if style.get('draw_one_line', False):
        line = ROOT.TLine(xmin, 1.0, xmax, 1.0)
        line.SetLineStyle(2)
        line.SetLineColor(ROOT.kGray + 1)
        line.SetLineWidth(2)
        line.Draw('SAME')

    # ---- 图例 ----
    if style.get('legend'):
        lg = style['legend']
        leg = GetLegend(
            xmin=lg.get('xmin', 0.55),
            ymin=lg.get('ymin', 0.70),
            xmax=lg.get('xmax', 0.88),
            ymax=lg.get('ymax', 0.88),
            textsize=0.045,
            ncolumns=lg.get('ncolumns', 1),
            header=lg.get('header', '')
        )
        leg.AddEntry(h, lg.get('label_data', 'Data'), 'p')
        leg.AddEntry(fit_func, lg.get('label_fit', 'Fit (1 + #alpha_{1}#alpha_{2} #it{P} cos(#it{#theta}^{*}))'), 'l')
        leg.Draw('same')

    # ---- latex ----
    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    # ---- 拟合公式 + 参数 ----
    formula = TLatex()
    formula.SetNDC()
    formula.SetTextFont(42)
    formula.SetTextSize(style.get('formula_textsize', 0.035))
    formula.SetTextColor(get_root_constant(style.get('formula_color', 'kBlack')))


    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")


# ------------------------------------------------------------------
# 4. Helper: draw two TH1D on the same canvas
# ------------------------------------------------------------------
def draw_two_th1d(key, style_key, hist_specs):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]

    syst_file = style.get('syst_file', None)
    syst_map = {}
    if syst_file:
        syst_map = {
            'hP_US_vsR': LoadSystFromTH1(syst_file, style.get('syst_object_US', 'h_RMS_total_US')),
            'hP_SS_vsR': LoadSystFromTH1(syst_file, style.get('syst_object_SS', 'h_RMS_total_SS')),
        }
        us_vals = list(syst_map['hP_US_vsR'].values())
        ss_vals = list(syst_map['hP_SS_vsR'].values())
        print(f"[syst_map] US first 3: {us_vals[:3]}")
        print(f"[syst_map] SS first 3: {ss_vals[:3]}")
        print(f"[syst_map] US == SS: {us_vals == ss_vals}")

    half_width = style.get('syst_half_width', 0.05)

    hist_list = []
    box_list = []
    ymax_auto = 0.0

    for spec in hist_specs:
        inp = config['input'][spec['input_key']]
        h, infile = LoadObjectFromFile(inp['file'], inp['object'])
        if not h:
            raise RuntimeError(f"Cannot load {spec['input_key']}")

        h.SetLineColor(get_root_constant(spec['color']))
        h.SetMarkerColor(get_root_constant(spec['color']))
        h.SetMarkerStyle(get_root_constant(spec['marker']))
        h.SetMarkerSize(spec.get('markersize', 3.2))
        h.SetLineWidth(spec.get('linewidth', 5))

        box = None
        if spec['input_key'] in syst_map:
            syst_dict = syst_map[spec['input_key']]
            box = MakeSystBoxFixedWidth(h, syst_dict, half_width=half_width)
            box.SetFillStyle(0)
            box.SetLineColor(get_root_constant(spec['color']))
            box.SetLineWidth(style.get('syst_linewidth', 2))
            box.SetMarkerSize(0)

            for i in range(1, h.GetNbinsX() + 1):
                s = syst_dict.get(i, 0.0)
                ymax_auto = max(ymax_auto, h.GetBinContent(i) + s)
        else:
            for i in range(1, h.GetNbinsX() + 1):
                ymax_auto = max(ymax_auto, h.GetBinContent(i) + h.GetBinError(i))

        hist_list.append((h, spec['label']))
        box_list.append(box)

    for i, box in enumerate(box_list):
        if box:
            print(f"[box] i={i}  key={hist_specs[i]['input_key']}  "
                  f"name={box.GetName()}  color={box.GetLineColor()}  "
                  f"N={box.GetN()}  half_width={half_width}")
        else:
            print(f"[box] i={i}  key={hist_specs[i]['input_key']}  is_none=True")

    xmin = style.get('xmin', hist_list[0][0].GetXaxis().GetXmin())
    xmax = style.get('xmax', hist_list[0][0].GetXaxis().GetXmax())
    ymin = style.get('ymin', 0.0)
    ymax = style.get('ymax', -1)
    if ymax < 0:
        ymax = ymax_auto * style.get('yrange_scale', 1.4)

    print(f"[plot] xmin={xmin} xmax={xmax} ymin={ymin} ymax={ymax}")

    c = ROOT.TCanvas(f'c_{key}', f'c_{key}', 1600, 1600)
    gs = config.get('global_style', {})
    c.SetLeftMargin(gs.get('padleftmargin', 0.18))
    c.SetRightMargin(gs.get('padrightmargin', 0.04))
    c.SetTopMargin(gs.get('padtopmargin', 0.06))
    c.SetBottomMargin(gs.get('padbottommargin', 0.12))
    if style.get('setlogx', False):
        c.SetLogx()
    if style.get('setlogy', False):
        c.SetLogy()

    drawopt = style.get('drawopt', 'E')
    black_outline = style.get('black_outline', False)
    outline_scale = style.get('outline_scale', 1.4)

    # 1) axes
    h0, _ = hist_list[0]
    h0.GetXaxis().SetRangeUser(xmin, xmax)
    h0.GetYaxis().SetRangeUser(ymin, ymax)
    h0.GetXaxis().SetTitleOffset(1.2)
    h0.SetTitle(style.get('axisname', ';;'))
    h0.Draw('AXIS')

    # 2) draw each group in reverse order: SS first (box + points), then US (box + points) on top
    for (h, _), box in zip(reversed(hist_list), reversed(box_list)):
        # syst box first for this group
        if box:
            box.Draw('E2 same')
        # then data points for this group
        if black_outline:
            DrawMarkerWithBlackOutline(
                h, drawopt=drawopt,
                color=h.GetMarkerColor(),
                markerstyle=h.GetMarkerStyle(),
                markersize=h.GetMarkerSize(),
                outline_scale=outline_scale
            )
        else:
            h.Draw(f'{drawopt} same')

    # 4) legend
    leg_cfg = style.get('legend', {})
    leg = GetLegend(
        xmin=leg_cfg.get('xmin', 0.50),
        ymin=leg_cfg.get('ymin', 0.68),
        xmax=leg_cfg.get('xmax', 0.90),
        ymax=leg_cfg.get('ymax', 0.82),
        textsize=0.045,
        ncolumns=leg_cfg.get('ncolumns', 1),
        header=leg_cfg.get('header', '')
    )
    for h, label in hist_list:
        if black_outline:
            h_leg = create_empty_clone(h, markersize_scale=1.2)
        else:
            h_leg = create_legend_clone(h)
        leg.AddEntry(h_leg, label, 'p')
    leg.Draw('same')

    if style.get('draw_zero_line', False):
        DrawLineAt0(xmin, xmax).Draw('same')

    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")



# ------------------------------------------------------------------
# 4b. Helper: draw US data + two model profiles on one canvas
#     US 带系统误差盒子；模型画法参考 ROOT 宏：SAME E3 + FillColor + LineWidth 5
# ------------------------------------------------------------------
# ------------------------------------------------------------------
# 4b. Helper: draw US data + two model profiles on one canvas
#     US 带系统误差盒子（但 legend 不列 sys.uncertainty）
#     模型画法参考 ROOT 宏：SAME E3 + FillColor + LineWidth 5
# ------------------------------------------------------------------
# ------------------------------------------------------------------
# 4b. Helper: draw US data + two model profiles on one canvas
#     US 的点、误差盒子样式与第三张图（US+SS）完全一致
#     模型画法参考 ROOT 宏：SAME E3 + FillColor + LineWidth 5
# ------------------------------------------------------------------

def draw_us_with_models(key, style_key):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]

    # ---- load US data ----
    inp = config['input']['hP_US_vsR']
    h, infile = LoadObjectFromFile(inp['file'], inp['object'])
    if not h:
        raise RuntimeError("Cannot load hP_US_vsR for model plot")

    # ---- US style ----
    US_COLOR      = get_root_constant(style.get('us_color', 'kRed'))
    US_MARKER     = get_root_constant(style.get('us_marker', 'kFullCircle'))
    US_MARKERSIZE = style.get('us_markersize', 3.0)
    US_LINEWIDTH  = style.get('us_linewidth', 5)

    h.SetLineColor(US_COLOR)
    h.SetMarkerColor(US_COLOR)
    h.SetMarkerStyle(US_MARKER)
    h.SetMarkerSize(US_MARKERSIZE)
    h.SetLineWidth(US_LINEWIDTH)

    # ---- US systematic uncertainty ----
    usss_style = config.get('hP_USSS_vsR_style', {})
    syst_file      = usss_style.get('syst_file', None)
    syst_object    = usss_style.get('syst_object_US', None)
    syst_linewidth = usss_style.get('syst_linewidth', 3)
    half_width     = usss_style.get('syst_half_width', 0.05)

    syst_dict = None
    if syst_file and syst_object:
        syst_dict = LoadSystFromTH1(syst_file, syst_object)

    xmin = style.get('xmin', h.GetXaxis().GetXmin())
    xmax = style.get('xmax', h.GetXaxis().GetXmax())
    ymin = style.get('ymin', 0.0)
    ymax = style.get('ymax', -1)

    # ---- load model profiles ----
    model_file = style.get('model_file', None)
    h_SU6 = None
    h_BJ  = None
    if model_file:
        mf = ROOT.TFile.Open(model_file, 'READ')
        if mf and not mf.IsZombie():
            obj_SU6 = mf.Get(style.get('model_SU6_object', 'prof_R_SU6_nominal'))
            obj_BJ  = mf.Get(style.get('model_BJ_object',  'prof_R_BJ_nominal'))
            if obj_SU6:
                h_SU6 = obj_SU6.Clone('h_SU6_model')
                h_SU6.SetDirectory(0)
            if obj_BJ:
                h_BJ = obj_BJ.Clone('h_BJ_model')
                h_BJ.SetDirectory(0)
            mf.Close()

    # VSC
    g_vsc = None
    points = []
    vsc_file = style.get('vsc_file')
    if vsc_file and os.path.isfile(vsc_file):
        import math
        with open(vsc_file, 'r') as stream:
            for lineno, raw in enumerate(stream, 1):
                row = raw.strip()
                if not row or row.startswith('#'):
                    continue
                fields = row.split()
                if len(fields) != 2:
                    raise ValueError(f'{vsc_file}:{lineno}: expected two columns')
                x, y = map(float, fields)
                if not (math.isfinite(x) and math.isfinite(y)):
                    raise ValueError(f'{vsc_file}:{lineno}: non-finite value')
                points.append((x, y))
        points.sort()
        if len(points) >= 2:
            g_vsc = ROOT.TGraph(len(points))
            g_vsc.SetName(f'{key}_VSC_CMS13TeV')
            for i, (x, y) in enumerate(points):
                g_vsc.SetPoint(i, x, y)
            g_vsc.SetLineColor(get_root_constant(style.get('vsc_color', 'kGreen+2')))
            g_vsc.SetLineWidth(style.get('vsc_linewidth', 4))
            g_vsc.SetLineStyle(style.get('vsc_linestyle', 1))
            g_vsc.SetFillStyle(0)
            g_vsc.SetMarkerSize(0)
        else:
            print(f"[warn] Not enough VSC points in {vsc_file}, skipping VSC curve")
    elif vsc_file:
        print(f"[warn] VSC file not found, skipping: {vsc_file}")

    # ---- y-range ----
    if ymax < 0:
        ymax_auto = 0.0
        for i in range(1, h.GetNbinsX() + 1):
            if syst_dict:
                s = syst_dict.get(i, 0.0)
                ymax_auto = max(ymax_auto, h.GetBinContent(i) + s)
            else:
                ymax_auto = max(ymax_auto, h.GetBinContent(i) + h.GetBinError(i))
        if h_SU6:
            for i in range(1, h_SU6.GetNbinsX() + 1):
                ymax_auto = max(ymax_auto,
                                h_SU6.GetBinContent(i) + h_SU6.GetBinError(i))
        if h_BJ:
            for i in range(1, h_BJ.GetNbinsX() + 1):
                ymax_auto = max(ymax_auto,
                                h_BJ.GetBinContent(i) + h_BJ.GetBinError(i))
        if g_vsc is not None:
            for x, y in points:
                if xmin <= x <= xmax:
                    ymax_auto = max(ymax_auto, y)
        ymax = ymax_auto * style.get('yrange_scale', 1.4)

    h.GetXaxis().SetRangeUser(xmin, xmax)
    h.GetYaxis().SetRangeUser(ymin, ymax)

    # ---- canvas ----
    c = ROOT.TCanvas(f'c_{key}', f'c_{key}', 1600, 1500)
    gs = config.get('global_style', {})
    c.SetLeftMargin(gs.get('padleftmargin', 0.18))
    c.SetRightMargin(gs.get('padrightmargin', 0.04))
    c.SetTopMargin(gs.get('padtopmargin', 0.06))
    c.SetBottomMargin(gs.get('padbottommargin', 0.12))
    if style.get('setlogx', False):
        c.SetLogx()
    if style.get('setlogy', False):
        c.SetLogy()

    # ---- axes frame ----
    h.SetTitle(style.get('axisname', ';;'))
    h.GetXaxis().SetTitleOffset(1.2)
    h.GetYaxis().SetTitleOffset(1.6)
    h.GetYaxis().ChangeLabel(1, -1, 0)   # 隐去纵轴第一个刻度标签
    h.Draw('AXIS')

    # ---- model curves ----
    if h_SU6:
        su6_col = get_root_constant(style.get('model_SU6_color', 'kBlack'))
        su6_ls  = style.get('model_SU6_linestyle', 1)
        su6_lw  = style.get('model_linewidth', 3)

        h_SU6.SetLineColor(su6_col)
        h_SU6.SetLineStyle(su6_ls)
        h_SU6.SetLineWidth(su6_lw)
        h_SU6.SetMarkerColor(su6_col)
        h_SU6.SetMarkerStyle(33)
        h_SU6.SetMarkerSize(0)
        h_SU6.SetFillColor(su6_col)
        h_SU6.Draw('SAME E3')

        h_SU6_line = h_SU6.Clone(f'{key}_h_SU6_centerline')
        try:
            h_SU6_line.SetDirectory(0)
        except AttributeError:
            pass
        h_SU6_line.SetFillStyle(0)
        h_SU6_line.SetFillColor(0)
        h_SU6_line.SetLineColor(su6_col)
        h_SU6_line.SetLineStyle(su6_ls)
        h_SU6_line.SetLineWidth(su6_lw)
        h_SU6_line.Draw('HIST L SAME')

    if h_BJ:
        bj_col = get_root_constant(style.get('model_BJ_color', 'kBlack'))
        bj_ls  = style.get('model_BJ_linestyle', 2)
        bj_lw  = style.get('model_linewidth', 3)

        h_BJ.SetLineColor(bj_col)
        h_BJ.SetLineStyle(bj_ls)
        h_BJ.SetLineWidth(bj_lw)
        h_BJ.SetMarkerColor(bj_col)
        h_BJ.SetMarkerStyle(34)
        h_BJ.SetMarkerSize(0)
        h_BJ.SetFillColor(bj_col)
        h_BJ.Draw('SAME E3')

        h_BJ_line = h_BJ.Clone(f'{key}_h_BJ_centerline')
        try:
            h_BJ_line.SetDirectory(0)
        except AttributeError:
            pass
        h_BJ_line.SetFillStyle(0)
        h_BJ_line.SetFillColor(0)
        h_BJ_line.SetLineColor(bj_col)
        h_BJ_line.SetLineStyle(bj_ls)
        h_BJ_line.SetLineWidth(bj_lw)
        h_BJ_line.Draw('HIST L SAME')

    if g_vsc is not None:
        g_vsc.Draw('L SAME')

    # ---- US syst box ----
    if syst_dict:
        box = MakeSystBoxFixedWidth(h, syst_dict, half_width=half_width)
        box.SetFillStyle(0)
        box.SetLineColor(US_COLOR)
        box.SetLineWidth(syst_linewidth)
        box.SetMarkerSize(0)
        box.Draw('E2 same')

    # ---- US data points ----
    h.Draw(f"{style.get('drawopt', 'E')} SAME")

    # ---- zero line（与 hP_US_vsR 同款，可从 YAML 配）----
    if style.get('draw_zero_line', False):
        line = ROOT.TLine(xmin, style.get('zero_line_y', 0.0),
                          xmax, style.get('zero_line_y', 0.0))
        line.SetLineStyle(style.get('zero_line_style', 2))
        line.SetLineColor(get_root_constant(style.get('zero_line_color', 'kGray+1')))
        line.SetLineWidth(style.get('zero_line_width', 2))
        line.Draw('SAME')

    # ================================================================
    # 图例：Data / SU6 / BJ / VSC 全部放在同一个 TLegend 里
    # 三个模拟条目统一用空 TH1D 代理，线段长度/符号宽度一致
    # ================================================================
    leg_cfg       = style.get('legend', {})
    legend_margin = style.get('legend_margin', 0.22)
    legend_lw     = style.get('legend_linewidth', 6)
    legend_tsize  = leg_cfg.get('textsize', 0.040)

    def make_leg_proxy(name, color, linestyle, linewidth):
        """空 TH1D，仅用于图例，保证线段/符号宽度一致。"""
        p = ROOT.TH1D(name, '', 1, 0, 1)
        p.SetDirectory(0)
        p.SetLineColor(color)
        p.SetLineStyle(linestyle)
        p.SetLineWidth(linewidth)
        p.SetMarkerSize(0)
        p.SetFillStyle(0)
        return p

    def finalize_legend(leg, margin=legend_margin, tsize=legend_tsize):
        leg.SetMargin(margin)
        leg.SetTextFont(42)
        leg.SetTextSize(tsize)
        for entry in leg.GetListOfPrimitives():
            if entry.InheritsFrom('TLegendEntry'):
                entry.SetTextFont(42)
                entry.SetTextSize(tsize)
                try:
                    entry.SetLineLength(margin)
                except AttributeError:
                    pass
        return leg

    leg = GetLegend(
        xmin=leg_cfg.get('xmin', 0.50),
        ymin=leg_cfg.get('ymin', 0.62),
        xmax=leg_cfg.get('xmax', 0.92),
        ymax=leg_cfg.get('ymax', 0.88),
        textsize=legend_tsize,
        ncolumns=leg_cfg.get('ncolumns', 1),
        header=leg_cfg.get('header', '')
    )

    # Data
    h_us_leg = create_legend_clone(h)
    leg.AddEntry(h, 'Data', 'pe')

    # SU(6)
    if h_SU6:
        h_SU6_leg = make_leg_proxy(
            f'{key}_SU6_leg_proxy',
            get_root_constant(style.get('model_SU6_color', 'kBlack')),
            style.get('model_SU6_linestyle', 1),
            legend_lw
        )
        leg.AddEntry(h_SU6_leg, 'PYTHIA 8, BLC-CR mode 1 + SU(6)', 'l')

    # BJ
    if h_BJ:
        h_BJ_leg = make_leg_proxy(
            f'{key}_BJ_leg_proxy',
            get_root_constant(style.get('model_BJ_color', 'kBlack')),
            style.get('model_BJ_linestyle', 2),
            legend_lw
        )
        leg.AddEntry(h_BJ_leg, 'PYTHIA 8, BLC-CR mode 1 + BJ', 'l')

    # VSC（同一个 legend）
    if g_vsc is not None:
        h_vsc_leg = make_leg_proxy(
            f'{key}_VSC_leg_proxy',
            g_vsc.GetLineColor(),
            style.get('vsc_linestyle', 1),
            legend_lw
        )
        vsc_label = style.get('vsc_legend_label',
                              style.get('vsc_label', 'VSC model'))
        leg.AddEntry(h_vsc_leg, vsc_label, 'l')

    finalize_legend(leg)
    leg.Draw('same')

    # ---- latex ----
    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)

    # ---- 最后恢复图例字号（enforce / review_layout 都会覆盖）----
    leg.SetTextSize(legend_tsize)
    for entry in leg.GetListOfPrimitives():
        if entry.InheritsFrom('TLegendEntry'):
            entry.SetTextFont(42)
            entry.SetTextSize(legend_tsize)
    c.Modified()
    c.Update()

    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")

# ------------------------------------------------------------------
# 4b-2. Helper: US data + STAR data on one canvas
#       US 样式与第三张图一致；STAR 是 TGraph
# ------------------------------------------------------------------
# ------------------------------------------------------------------
# 4b-2. Helper: US data + STAR data on one canvas
#       US 样式与第三张图一致；STAR 是 TGraph
#       STAR 系统误差来自 Hist_y1_e2（TH1D），用盒子叠在 STAR 点上
# ------------------------------------------------------------------
def draw_us_with_star(key, style_key):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]

    # ---- load US data ----
    inp = config['input']['hP_US_vsR']
    h_us, _ = LoadObjectFromFile(inp['file'], inp['object'])
    if not h_us:
        raise RuntimeError("Cannot load hP_US_vsR for US vs STAR plot")

    # ---- US style（与第三张图 US 一致）----
    us_color  = get_root_constant(style.get('us_color',  'kBlue+3'))
    us_marker = get_root_constant(style.get('us_marker', 'kFullCircle'))
    h_us.SetLineColor(us_color)
    h_us.SetMarkerColor(us_color)
    h_us.SetMarkerStyle(us_marker)
    h_us.SetMarkerSize(style.get('us_markersize', 3.0))
    h_us.SetLineWidth(style.get('us_linewidth', 5))

    # ---- US syst ----
    syst_dict = None
    syst_file   = style.get('syst_file', None)
    syst_object = style.get('syst_object_US', None)
    half_width  = style.get('syst_half_width', 0.05)
    if syst_file and syst_object:
        syst_dict = LoadSystFromTH1(syst_file, syst_object)

    # ---- load STAR TGraphAsymmErrors ----
    star_inp = config['input']['hP_STAR']
    f_star = ROOT.TFile.Open(star_inp['file'], 'READ')
    if not f_star or f_star.IsZombie():
        raise RuntimeError(f"Cannot open {star_inp['file']}")
    g_star = f_star.Get(star_inp['object'])
    if not g_star:
        f_star.Close()
        raise RuntimeError(f"Cannot find {star_inp['object']} in {star_inp['file']}")
    g_star = g_star.Clone('g_star_clone')
    try:
        g_star.SetDirectory(0)
    except AttributeError:
        pass
    f_star.Close()

    star_color  = get_root_constant(style.get('star_color',  'kBlack'))
    star_marker = get_root_constant(style.get('star_marker', 'kFullCircle'))
    g_star.SetMarkerStyle(star_marker)
    g_star.SetMarkerColor(star_color)
    g_star.SetMarkerSize(style.get('star_markersize', 2.0))
    g_star.SetLineColor(star_color)
    g_star.SetLineWidth(style.get('star_linewidth', 2))

    # ---- load STAR syst (TH1D: Hist_y1_e2) ----
    star_syst_hist = None
    star_syst_inp = config['input'].get('hP_STAR_syst', None)
    if star_syst_inp:
        f_s = ROOT.TFile.Open(star_syst_inp['file'], 'READ')
        if f_s and not f_s.IsZombie():
            obj = f_s.Get(star_syst_inp['object'])
            if obj:
                star_syst_hist = obj.Clone('h_star_syst')
                try:
                    star_syst_hist.SetDirectory(0)
                except AttributeError:
                    pass
            f_s.Close()

    star_syst_half_width  = style.get('star_syst_half_width',  half_width)
    star_syst_linewidth   = style.get('star_syst_linewidth',   2)

    # ---- 用 g_star 的 (x, y) 构造系统误差盒子，中心落在数据点上 ----
    g_star_syst = None
    if star_syst_hist:
        n_pts = g_star.GetN()
        g_star_syst = ROOT.TGraphAsymmErrors(n_pts)
        for i in range(n_pts):
            x = g_star.GetX()[i]
            y = g_star.GetY()[i]
            ib = star_syst_hist.FindBin(x)
            s  = star_syst_hist.GetBinContent(ib)   # 绝对误差，不乘 y

            g_star_syst.SetPoint(i, x, y)
            g_star_syst.SetPointEXlow(i,  star_syst_half_width)
            g_star_syst.SetPointEXhigh(i, star_syst_half_width)
            g_star_syst.SetPointEYlow(i,  s)
            g_star_syst.SetPointEYhigh(i, s)

        g_star_syst.SetFillStyle(0)
        g_star_syst.SetLineColor(star_color)
        g_star_syst.SetLineWidth(star_syst_linewidth)
        g_star_syst.SetMarkerSize(0)

    # ---- x/y range ----
    xmin = style.get('xmin', h_us.GetXaxis().GetXmin())
    xmax = style.get('xmax', h_us.GetXaxis().GetXmax())
    ymin = style.get('ymin', 0.0)
    ymax = style.get('ymax', -1)

    if ymax < 0:
        ymax_auto = 0.0
        # US
        for i in range(1, h_us.GetNbinsX() + 1):
            if syst_dict:
                s = syst_dict.get(i, 0.0)
                ymax_auto = max(ymax_auto, h_us.GetBinContent(i) + s)
            else:
                ymax_auto = max(ymax_auto, h_us.GetBinContent(i) + h_us.GetBinError(i))
        # STAR 统计误差
        for i in range(g_star.GetN()):
            y  = g_star.GetY()[i]
            ey = g_star.GetEY()[i]
            ymax_auto = max(ymax_auto, y + ey)
        # STAR 系统误差
        if g_star_syst:
            for i in range(g_star_syst.GetN()):
                y  = g_star_syst.GetY()[i]
                ey = g_star_syst.GetEYhigh()[i]
                ymax_auto = max(ymax_auto, y + ey)
        ymax = ymax_auto * style.get('yrange_scale', 1.4)

    h_us.GetXaxis().SetRangeUser(xmin, xmax)
    h_us.GetYaxis().SetRangeUser(ymin, ymax)

    # ---- canvas ----
    c = ROOT.TCanvas(f'c_{key}', f'c_{key}', 1600, 1600)
    gs = config.get('global_style', {})
    c.SetLeftMargin(gs.get('padleftmargin', 0.18))
    c.SetRightMargin(gs.get('padrightmargin', 0.04))
    c.SetTopMargin(gs.get('padtopmargin', 0.06))
    c.SetBottomMargin(gs.get('padbottommargin', 0.12))
    if style.get('setlogx', False):
        c.SetLogx()
    if style.get('setlogy', False):
        c.SetLogy()

    # ---- axes frame ----
    h_us.SetTitle(style.get('axisname', ';;'))
    h_us.GetXaxis().SetTitleOffset(1.2)
    h_us.GetYaxis().SetTitleOffset(2.0)
    h_us.Draw('AXIS')

    # ---- US syst box ----
    if syst_dict:
        box = MakeSystBoxFixedWidth(h_us, syst_dict, half_width=half_width)
        box.SetFillStyle(0)
        box.SetLineColor(us_color)
        box.SetLineWidth(style.get('syst_linewidth', 3))
        box.SetMarkerSize(0)
        box.Draw('E2 same')

    # ---- STAR syst box（中心在 g_star 的数据点上）----
    if g_star_syst:
        g_star_syst.Draw('E2 same')

    # ---- STAR first (so US points sit on top) ----
    g_star.Draw('E1 P same')

    # ---- US data points ----
    h_us.Draw(f"{style.get('drawopt', 'E')} SAME")

    # ---- zero line ----
    if style.get('draw_zero_line', False):
        DrawLineAt0(xmin, xmax).Draw('same')

    # ---- legend ----
    leg_cfg = style.get('legend', {})
    leg = GetLegend(
        xmin=leg_cfg.get('xmin', 0.60),
        ymin=leg_cfg.get('ymin', 0.66),
        xmax=leg_cfg.get('xmax', 0.90),
        ymax=leg_cfg.get('ymax', 0.88),
        textsize=0.045,
        ncolumns=leg_cfg.get('ncolumns', 1),
        header=leg_cfg.get('header', '')
    )

    h_us_leg = create_legend_clone(h_us)
    leg.AddEntry(h_us_leg, '#Lambda#bar{#Lambda} (ALICE)', 'lp')
    leg.AddEntry(g_star, '#Lambda#bar{#Lambda} (STAR)', 'lep')
    
    leg.Draw('same')

    # ---- latex ----
    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")
# ------------------------------------------------------------------
# 4b-2b. Helper: US data (scaled) + STAR data on one canvas
#         把 US 数据点（及系统误差）乘一个缩放因子，
#         使其在图上与 STAR 数据点基本重合。
# ------------------------------------------------------------------


# ------------------------------------------------------------------
# 4b-3. Helper: Rbin0 的 SE / ME 信号分数画在同一张图上
# ------------------------------------------------------------------
def draw_se_me_sigfrac(key, style_key):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]

        # ---- 根据 key 拼出 SE / ME 的 input key ----
    # key 形如 'hSigFrac_SE_ME_Rbin0' 或 'hSigFrac_SE_ME_Rbin0_SS'
    suffix_key = key.replace('hSigFrac_SE_ME_Rbin0', '')   # '' 或 '_SS'
    se_key = f'hSigFrac_SE_Rbin0{suffix_key}'
    me_key = f'hSigFrac_ME_Rbin0{suffix_key}'

    # ---- load SE ----
    inp_se = config['input'][se_key]
    h_se, _ = LoadObjectFromFile(inp_se['file'], inp_se['object'])
    if not h_se:
        raise RuntimeError(f"Cannot load {se_key}")

    # ---- load ME ----
    inp_me = config['input'][me_key]
    h_me, _ = LoadObjectFromFile(inp_me['file'], inp_me['object'])
    if not h_me:
        raise RuntimeError(f"Cannot load {me_key}")

    # ---- SE style ----
    se_color  = get_root_constant(style.get('se_color',  'kRed+1'))
    se_marker = get_root_constant(style.get('se_marker', 'kFullCircle'))
    h_se.SetLineColor(se_color)
    h_se.SetMarkerColor(se_color)
    h_se.SetMarkerStyle(se_marker)
    h_se.SetMarkerSize(style.get('se_markersize', 3.0))
    h_se.SetLineWidth(style.get('se_linewidth', 5))

    # ---- ME style ----
    me_color  = get_root_constant(style.get('me_color',  'kBlue+3'))
    me_marker = get_root_constant(style.get('me_marker', 'kFullSquare'))
    h_me.SetLineColor(me_color)
    h_me.SetMarkerColor(me_color)
    h_me.SetMarkerStyle(me_marker)
    h_me.SetMarkerSize(style.get('me_markersize', 3.0))
    h_me.SetLineWidth(style.get('me_linewidth', 5))

    # ---- x/y range ----
    xmin = style.get('xmin', h_se.GetXaxis().GetXmin())
    xmax = style.get('xmax', h_se.GetXaxis().GetXmax())
    ymin = style.get('ymin', None)
    ymax = style.get('ymax', -1)

    if ymax < 0:
        ymax_auto = 0.0
        for h in (h_se, h_me):
            for i in range(1, h.GetNbinsX() + 1):
                ymax_auto = max(ymax_auto,
                                h.GetBinContent(i) + h.GetBinError(i))
        ymax = ymax_auto * style.get('yrange_scale', 1.4)

    if ymin is None:
        ymin = 0.0

    h_se.GetXaxis().SetRangeUser(xmin, xmax)
    h_se.GetYaxis().SetRangeUser(ymin, ymax)

    # ---- canvas（和前面几张一致 1600x1600）----
    c = ROOT.TCanvas(f'c_{key}', f'c_{key}', 1600, 1600)
    gs = config.get('global_style', {})
    c.SetLeftMargin(gs.get('padleftmargin', 0.18))
    c.SetRightMargin(gs.get('padrightmargin', 0.04))
    c.SetTopMargin(gs.get('padtopmargin', 0.06))
    c.SetBottomMargin(gs.get('padbottommargin', 0.12))
    if style.get('setlogx', False):
        c.SetLogx()
    if style.get('setlogy', False):
        c.SetLogy()

    # ---- axes frame：用 SE 画轴 ----
    h_se.SetTitle(style.get('axisname', ';;'))
    h_se.GetXaxis().SetTitleOffset(1.2)
    h_se.GetYaxis().SetTitleOffset(2.0)
    h_se.GetYaxis().SetRangeUser(ymin, ymax)
    h_se.Draw('AXIS')

    # 细调刻度（和 hSE/hME 图一致）
    n_div_x = style.get('ndiv_x', 4)
    n_div_y = style.get('ndiv_y', 4)
    h_se.GetXaxis().SetNdivisions(n_div_x, False)
    h_se.GetYaxis().SetNdivisions(n_div_y, False)

    # ---- 先画 ME，再画 SE，让 SE 在上层（可自行调换）----
    h_me.Draw(f"{style.get('drawopt', 'E')} SAME")
    h_se.Draw(f"{style.get('drawopt', 'E')} SAME")

    # ---- zero line（可选）----
    if style.get('draw_zero_line', False):
        DrawLineAt0(xmin, xmax).Draw('same')

    # ---- legend ----
    leg_cfg = style.get('legend', {})
    leg = GetLegend(
        xmin=leg_cfg.get('xmin', 0.60),
        ymin=leg_cfg.get('ymin', 0.72),
        xmax=leg_cfg.get('xmax', 0.90),
        ymax=leg_cfg.get('ymax', 0.88),
        textsize=0.045,
        ncolumns=leg_cfg.get('ncolumns', 1),
        header=leg_cfg.get('header', '')
    )
    h_se_leg = create_legend_clone(h_se)
    h_me_leg = create_legend_clone(h_me)
    leg.AddEntry(h_se_leg, 'SE', 'p')
    leg.AddEntry(h_me_leg, 'ME', 'p')
    leg.Draw('same')

    # ---- latex ----
    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")


# ------------------------------------------------------------------
# 4c. Helper: 只画左 pad（m_Λ1），叠 6 条曲线，不画 ratio
#     输入是 extract_cSE 输出的 root 文件
# ------------------------------------------------------------------
def draw_extracted_cSE(key, style_key):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]

    inp_file = style.get('input_file')
    prefix   = style.get('prefix', 'c_SE_R0_c01')

    # ---- 读 6 个 TGraphErrors（只用左侧）----
    f_in = ROOT.TFile.Open(inp_file, 'READ')
    if not f_in or f_in.IsZombie():
        raise RuntimeError(f"Cannot open {inp_file}")

    def get_g(name):
        g = f_in.Get(name)
        if not g:
            raise RuntimeError(f"Cannot find {name} in {inp_file}")
        return g

    g_data = get_g(f'{prefix}_datax')
    g_tot  = get_g(f'{prefix}_totx')
    g_ss   = get_g(f'{prefix}_ssx')
    g_sb   = get_g(f'{prefix}_sbx')
    g_bs   = get_g(f'{prefix}_bsx')
    g_bb   = get_g(f'{prefix}_bbx')

    f_in.Close()

    # ---- unified font size ----
    gs = config.get('global_style', {})
    AXIS_FONT = style.get('axis_font_size', gs.get('labelsize', 0.045))
    LEG_FONT  = style.get('legend', {}).get('textsize', AXIS_FONT)

    # ---- 样式 ----
    col_data  = get_root_constant(style.get('color_data',  'kBlack'))
    col_total = get_root_constant(style.get('color_total', 'kBlack'))
    col_ss    = get_root_constant(style.get('color_ss',    'kRed+1'))
    col_sb    = get_root_constant(style.get('color_sb',    'kBlue+1'))
    col_bs    = get_root_constant(style.get('color_bs',    'kGreen+2'))
    col_bb    = get_root_constant(style.get('color_bb',    'kMagenta+1'))

    mk_data   = get_root_constant(style.get('marker_data', 'kFullCircle'))
    ms_data   = style.get('markersize_data', 2.0)
    lw        = style.get('linewidth', 2)
    lw_total  = style.get('linewidth_total', lw)

    ls_total  = style.get('linestyle_total', 1)
    ls_ss     = style.get('linestyle_ss',    1)
    ls_sb     = style.get('linestyle_sb',    2)
    ls_bs     = style.get('linestyle_bs',    1)
    ls_bb     = style.get('linestyle_bb',    4)

    g_data.SetMarkerStyle(mk_data)
    g_data.SetMarkerSize(ms_data)
    g_data.SetMarkerColor(col_data)
    g_data.SetLineColor(col_data)
    g_data.SetLineWidth(lw)

    for g, col, ls in ((g_ss, col_ss, ls_ss),
                       (g_sb, col_sb, ls_sb),
                       (g_bs, col_bs, ls_bs),
                       (g_bb, col_bb, ls_bb)):
        g.SetLineColor(col)
        g.SetLineStyle(ls)
        g.SetLineWidth(lw)
        g.SetMarkerSize(0)

    g_tot.SetLineColor(col_total)
    g_tot.SetLineStyle(ls_total)
    g_tot.SetLineWidth(lw_total)
    g_tot.SetMarkerSize(0)

    # ---- 画布 ----
    c = ROOT.TCanvas(f'c_{key}', f'c_{key}', 1600, 1600)

    c.SetLeftMargin(gs.get('padleftmargin', 0.14))
    c.SetRightMargin(gs.get('padrightmargin', 0.04))
    c.SetTopMargin(gs.get('padtopmargin', 0.08))
    c.SetBottomMargin(gs.get('padbottommargin', 0.12))

    if style.get('setlogx', False):
        c.SetLogx()
    if style.get('setlogy', False):
        c.SetLogy()

    xmin = style.get('xmin', 1.095)
    xmax = style.get('xmax', 1.135)

    ymin = style.get('ymin', None)
    ymax = style.get('ymax', -1)

    if ymax < 0:
        ymax_auto = 0.0
        ymin_auto = None
        for g in (g_data, g_tot, g_ss, g_sb, g_bs, g_bb):
            n = g.GetN()
            ys = g.GetY()
            eys = g.GetEY() if isinstance(g, ROOT.TGraphErrors) else None
            for i in range(n):
                y  = ys[i]
                ey = eys[i] if eys is not None else 0.0
                ymax_auto = max(ymax_auto, y + ey)
                if y > 0:
                    ymin_auto = y if ymin_auto is None else min(ymin_auto, y)
        ymax = ymax_auto * style.get('yrange_scale', 1.35)

        if ymin is None:
            if style.get('setlogy', False) and ymin_auto is not None:
                ymin = ymin_auto / style.get('yrange_scale', 1.35)
            else:
                ymin = 0.0
    elif ymin is None:
        ymin = 0.0

    # ---- 框架 ----
    h_frame = g_data.Clone(f'{key}_frame')
    h_frame.SetTitle('')
    h_frame.GetXaxis().SetRangeUser(xmin, xmax)
    h_frame.GetYaxis().SetRangeUser(ymin, ymax)
    h_frame.GetXaxis().SetTitle('#it{M}_{p#pi^{-}} (GeV/#it{c}^{2})')
    h_frame.GetYaxis().SetTitle('Counts/ 1.0 MeV/#it{c}^{2}')
    h_frame.GetYaxis().SetTitleOffset(style.get('y_title_offset', 2.0))
    h_frame.GetXaxis().SetTitleOffset(style.get('x_title_offset', 1.2))

    # ---- unify axis label/title size ----
    for ax in (h_frame.GetXaxis(), h_frame.GetYaxis()):
        ax.SetLabelFont(42)
        ax.SetTitleFont(42)
        ax.SetLabelSize(AXIS_FONT)
        ax.SetTitleSize(AXIS_FONT)

    h_frame.Draw('AP')

    # ---- 叠 6 条 ----
    g_tot.Draw('L SAME')
    g_ss .Draw('L SAME')
    g_sb .Draw('L SAME')
    g_bs .Draw('L SAME')
    g_bb .Draw('L SAME')
    g_data.Draw('P SAME')

    # ---- 图例 ----
    lc = style.get('legend', {})
    leg = GetLegend(
        xmin=lc.get('xmin', 0.50),
        ymin=lc.get('ymin', 0.55),
        xmax=lc.get('xmax', 0.88),
        ymax=lc.get('ymax', 0.85),
        textsize=LEG_FONT,
        ncolumns=lc.get('ncolumns', 1),
        header=lc.get('header', '')
    )
    data_legend = ROOT.TGraphErrors(1)
    data_legend.SetPoint(0, 0.0, 0.0)
    data_legend.SetPointError(0, 0.0, 1.0)
    data_legend.SetLineColor(g_data.GetLineColor())
    data_legend.SetLineWidth(2)
    data_legend.SetMarkerStyle(g_data.GetMarkerStyle())
    data_legend.SetMarkerColor(g_data.GetMarkerColor())
    data_legend.SetMarkerSize(g_data.GetMarkerSize())
    leg.AddEntry(data_legend, 'Data', 'pe')
    leg.AddEntry(g_tot,  'Total Fit', 'l')
    leg.AddEntry(g_ss,   'Sig.-Sig.',    'l')
    leg.AddEntry(g_sb,   'Sig.-Bkg.',    'l')
    leg.AddEntry(g_bs,   'Bkg.-Sig.',    'l')
    leg.AddEntry(g_bb,   'Bkg.-Bkg.',    'l')
    leg.Draw('same')

    # ---- latex ----
    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")



# ------------------------------------------------------------------
# 4d. Helper: 只画右 pad（m_Λ2），叠 6 条曲线
#     输入是 extract_cSE 输出的 root 文件，对象后缀为 _y
# ------------------------------------------------------------------
def draw_extracted_cSE_mLambda2(key, style_key):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]

    inp_file = style.get('input_file')
    prefix   = style.get('prefix', 'c_SE_R0_c01')

    # ---- 读 6 个 TGraphErrors（右 pad，后缀 _y）----
    f_in = ROOT.TFile.Open(inp_file, 'READ')
    if not f_in or f_in.IsZombie():
        raise RuntimeError(f"Cannot open {inp_file}")

    def get_g(name):
        g = f_in.Get(name)
        if not g:
            raise RuntimeError(f"Cannot find {name} in {inp_file}")
        return g

    g_data = get_g(f'{prefix}_datay')
    g_tot  = get_g(f'{prefix}_toty')
    g_ss   = get_g(f'{prefix}_ssy')
    g_sb   = get_g(f'{prefix}_sby')
    g_bs   = get_g(f'{prefix}_bsy')
    g_bb   = get_g(f'{prefix}_bby')

    f_in.Close()

    # ---- 样式（与第五张图完全一致）----
    col_data  = get_root_constant(style.get('color_data',  'kBlack'))
    col_total = get_root_constant(style.get('color_total', 'kBlack'))
    col_ss    = get_root_constant(style.get('color_ss',    'kRed+1'))
    col_sb    = get_root_constant(style.get('color_sb',    'kBlue+1'))
    col_bs    = get_root_constant(style.get('color_bs',    'kGreen+2'))
    col_bb    = get_root_constant(style.get('color_bb',    'kMagenta+1'))

    mk_data   = get_root_constant(style.get('marker_data', 'kFullCircle'))
    ms_data   = style.get('markersize_data', 2.0)
    lw        = style.get('linewidth', 2)
    lw_total  = style.get('linewidth_total', lw)

    ls_total  = style.get('linestyle_total', 1)
    ls_ss     = style.get('linestyle_ss',    1)
    ls_sb     = style.get('linestyle_sb',    2)
    ls_bs     = style.get('linestyle_bs',    1)
    ls_bb     = style.get('linestyle_bb',    4)

    g_data.SetMarkerStyle(mk_data)
    g_data.SetMarkerSize(ms_data)
    g_data.SetMarkerColor(col_data)
    g_data.SetLineColor(col_data)
    g_data.SetLineWidth(lw)

    for g, col, ls in ((g_ss, col_ss, ls_ss),
                       (g_sb, col_sb, ls_sb),
                       (g_bs, col_bs, ls_bs),
                       (g_bb, col_bb, ls_bb)):
        g.SetLineColor(col)
        g.SetLineStyle(ls)
        g.SetLineWidth(lw)
        g.SetMarkerSize(0)

    g_tot.SetLineColor(col_total)
    g_tot.SetLineStyle(ls_total)
    g_tot.SetLineWidth(lw_total)
    g_tot.SetMarkerSize(0)

    # ---- 画布 ----
    c = ROOT.TCanvas(f'c_{key}', f'c_{key}', 1600, 1600)

    gs = config.get('global_style', {})
    c.SetLeftMargin(gs.get('padleftmargin', 0.14))
    c.SetRightMargin(gs.get('padrightmargin', 0.06))
    c.SetTopMargin(gs.get('padtopmargin', 0.08))
    c.SetBottomMargin(gs.get('padbottommargin', 0.12))

    if style.get('setlogx', False):
        c.SetLogx()
    if style.get('setlogy', False):
        c.SetLogy()

    xmin = style.get('xmin', 1.095)
    xmax = style.get('xmax', 1.135)

    ymin = style.get('ymin', None)
    ymax = style.get('ymax', -1)

    if ymax < 0:
        ymax_auto = 0.0
        ymin_auto = None
        for g in (g_data, g_tot, g_ss, g_sb, g_bs, g_bb):
            n = g.GetN()
            ys = g.GetY()
            eys = g.GetEY() if isinstance(g, ROOT.TGraphErrors) else None
            for i in range(n):
                y  = ys[i]
                ey = eys[i] if eys is not None else 0.0
                ymax_auto = max(ymax_auto, y + ey)
                if y > 0:
                    ymin_auto = y if ymin_auto is None else min(ymin_auto, y)
        ymax = ymax_auto * style.get('yrange_scale', 1.35)

        if ymin is None:
            if style.get('setlogy', False) and ymin_auto is not None:
                ymin = ymin_auto / style.get('yrange_scale', 1.35)
            else:
                ymin = 0.0
    elif ymin is None:
        ymin = 0.0

    # 框架
    h_frame = g_data.Clone(f'{key}_frame')
    h_frame.SetTitle('')
    h_frame.GetXaxis().SetRangeUser(xmin, xmax)
    h_frame.GetYaxis().SetRangeUser(ymin, ymax)
    h_frame.GetXaxis().SetTitle('#it{M}_{#bar{p}#pi^{+}} (GeV/#it{c}^{2})')
    h_frame.GetYaxis().SetTitle('Counts/ 1.0 MeV/#it{c}^{2}')
    h_frame.GetYaxis().SetTitleOffset(2.0)
    h_frame.GetXaxis().SetTitleOffset(1.2)
    h_frame.Draw('AP')

    # 叠 6 条
    g_tot.Draw('L SAME')
    g_ss .Draw('L SAME')
    g_sb .Draw('L SAME')
    g_bs .Draw('L SAME')
    g_bb .Draw('L SAME')
    g_data.Draw('P SAME')

    # 图例
    lc = style.get('legend', {})
    leg = GetLegend(
        xmin=lc.get('xmin', 0.55),
        ymin=lc.get('ymin', 0.55),
        xmax=lc.get('xmax', 0.88),
        ymax=lc.get('ymax', 0.88),
        textsize=0.045,
        ncolumns=lc.get('ncolumns', 1),
        header=lc.get('header', '')
    )
    data_legend = ROOT.TGraphErrors(1)
    data_legend.SetPoint(0, 0.0, 0.0)
    data_legend.SetPointError(0, 0.0, 1.0)
    data_legend.SetLineColor(g_data.GetLineColor())
    data_legend.SetLineWidth(2)
    data_legend.SetMarkerStyle(g_data.GetMarkerStyle())
    data_legend.SetMarkerColor(g_data.GetMarkerColor())
    data_legend.SetMarkerSize(g_data.GetMarkerSize())
    leg.AddEntry(data_legend, 'Data', 'pe')
    leg.AddEntry(g_tot,  'Total Fit', 'l')
    leg.AddEntry(g_ss,   'Sig.-Sig.',    'l')
    leg.AddEntry(g_sb,   'Sig.-Bkg.',    'l')
    leg.AddEntry(g_bs,   'Bkg.-Sig.',    'l')
    leg.AddEntry(g_bb,   'Bkg.-Bkg.',    'l')

    leg.Draw('same')

    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")



def draw_us_with_star_inset(key, style_key):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]

    # ---- axis / frame line width ----
    axis_lw = style.get('axis_linewidth', 2)
    ROOT.gStyle.SetFrameLineWidth(axis_lw)
    ROOT.gStyle.SetFrameLineColor(ROOT.kBlack)

    # ---- unified font sizes ----
    gs = config.get('global_style', {})
    FONT_SIZE = style.get('font_size', gs.get('labelsize', 0.045))

    leg_cfg = style.get('legend', {})
    LEG_SIZE = leg_cfg.get('textsize', 0.1)

    info_leg_cfg = leg_cfg.get('info_legend', {})
    alice_leg_box = (
        info_leg_cfg.get('alice_x1', 0.025),
        info_leg_cfg.get('alice_y1', 0.79),
        info_leg_cfg.get('alice_x2', 0.98),
        info_leg_cfg.get('alice_y2', 0.86),
    )
    star_leg_box = (
        info_leg_cfg.get('star_x1', 0.025),
        info_leg_cfg.get('star_y1', 0.39),
        info_leg_cfg.get('star_x2', 0.98),
        info_leg_cfg.get('star_y2', 0.46),
    )

    ic = style.get('inset', {})
    INSET_LABEL_SIZE = ic.get('labelsize', 0.06)
    INSET_TITLE_SIZE = ic.get('titlesize', 0.06)

    # ---- load US data ----
    inp = config['input']['hP_US_vsR']
    h_us, _ = LoadObjectFromFile(inp['file'], inp['object'])
    if not h_us:
        raise RuntimeError("Cannot load hP_US_vsR for US vs STAR inset plot")

    us_color  = get_root_constant(style.get('us_color',  'kBlue+3'))
    us_marker = get_root_constant(style.get('us_marker', 'kFullCircle'))
    h_us.SetLineColor(us_color)
    h_us.SetMarkerColor(us_color)
    h_us.SetMarkerStyle(us_marker)
    h_us.SetMarkerSize(style.get('us_markersize', 3.0))
    h_us.SetLineWidth(style.get('us_linewidth', 5))

    syst_dict = None
    syst_file   = style.get('syst_file', None)
    syst_object = style.get('syst_object_US', None)
    half_width  = style.get('syst_half_width', 0.05)
    if syst_file and syst_object:
        syst_dict = LoadSystFromTH1(syst_file, syst_object)

    # ---- load STAR ----
    star_inp = config['input']['hP_STAR']
    f_star = ROOT.TFile.Open(star_inp['file'], 'READ')
    if not f_star or f_star.IsZombie():
        raise RuntimeError(f"Cannot open {star_inp['file']}")
    g_star = f_star.Get(star_inp['object'])
    if not g_star:
        f_star.Close()
        raise RuntimeError(f"Cannot find {star_inp['object']}")
    g_star = g_star.Clone('g_star_clone_inset')
    try:
        g_star.SetDirectory(0)
    except AttributeError:
        pass
    f_star.Close()

    star_color  = get_root_constant(style.get('star_color',  'kBlack'))
    star_marker = get_root_constant(style.get('star_marker', 'kFullCircle'))
    g_star.SetMarkerStyle(star_marker)
    g_star.SetMarkerColor(star_color)
    g_star.SetMarkerSize(style.get('star_markersize', 2.0))
    g_star.SetLineColor(star_color)
    g_star.SetLineWidth(style.get('star_linewidth', 2))

    star_syst_hist = None
    star_syst_inp = config['input'].get('hP_STAR_syst', None)
    if star_syst_inp:
        f_s = ROOT.TFile.Open(star_syst_inp['file'], 'READ')
        if f_s and not f_s.IsZombie():
            obj = f_s.Get(star_syst_inp['object'])
            if obj:
                star_syst_hist = obj.Clone('h_star_syst_inset')
                try:
                    star_syst_hist.SetDirectory(0)
                except AttributeError:
                    pass
            f_s.Close()

    star_syst_half_width = style.get('star_syst_half_width', half_width)
    star_syst_linewidth  = style.get('star_syst_linewidth', 2)

    g_star_syst = None
    if star_syst_hist:
        n_pts = g_star.GetN()
        g_star_syst = ROOT.TGraphAsymmErrors(n_pts)
        for i in range(n_pts):
            x = g_star.GetX()[i]
            y = g_star.GetY()[i]
            ib = star_syst_hist.FindBin(x)
            s  = star_syst_hist.GetBinContent(ib)
            g_star_syst.SetPoint(i, x, y)
            g_star_syst.SetPointEXlow(i,  star_syst_half_width)
            g_star_syst.SetPointEXhigh(i, star_syst_half_width)
            g_star_syst.SetPointEYlow(i,  s)
            g_star_syst.SetPointEYhigh(i, s)
        g_star_syst.SetFillStyle(0)
        g_star_syst.SetLineColor(star_color)
        g_star_syst.SetLineWidth(star_syst_linewidth)
        g_star_syst.SetMarkerSize(0)

    keep = [h_us, g_star, g_star_syst, star_syst_hist]

    xmin = style.get('xmin', 0.0)
    xmax = style.get('xmax', 3.1)
    ymin = style.get('ymin', -0.08)
    ymax = style.get('ymax', 0.70)
    if ymax <= ymin:
        raise ValueError("Set explicit ymin < ymax for the STAR comparison")

    c = ROOT.TCanvas(f'c_{key}', '', style.get('canvas_width', 1600),
                     style.get('canvas_height', 1050))
    c.SetFillColor(ROOT.kWhite)
    main = ROOT.TPad(f'main_{key}', '', 0.0, 0.0, 0.755, 1.0)
    info = ROOT.TPad(f'info_{key}', '', 0.755, 0.0, 1.0, 1.0)
    for pad in (main, info):
        pad.SetFillColor(ROOT.kWhite)
        pad.SetBorderMode(0)
        pad.Draw()
    keep += [main, info]

    main.cd()
    main.SetLeftMargin(0.14)
    main.SetRightMargin(0.025)
    main.SetBottomMargin(0.14)
    main.SetTopMargin(0.07)
    main.SetTicks(1, 1)
    main.SetLogx(style.get('setlogx', False))
    main.SetLogy(style.get('setlogy', False))

    parts = style.get('axisname', ';;').split(';')
    xtitle = parts[1] if len(parts) > 1 else '#Delta#it{R}'
    ytitle = parts[2] if len(parts) > 2 else 'P_{#Lambda#bar{#Lambda}}'

    def frame(pad, name, lo, hi, bottom, top, small=False):
        pad.cd()
        f = pad.DrawFrame(lo, bottom, hi, top)
        f.SetName(name)
        f.SetTitle('')
        f.SetLineWidth(axis_lw)
        f.SetLineColor(ROOT.kBlack)
        f.GetXaxis().SetTitle(xtitle)
        f.GetYaxis().SetTitle(ytitle)

        label_sz = INSET_LABEL_SIZE if small else FONT_SIZE
        title_sz = INSET_TITLE_SIZE if small else FONT_SIZE

        for ax in (f.GetXaxis(), f.GetYaxis()):
            ax.SetLabelFont(42)
            ax.SetTitleFont(42)
            ax.SetLabelSize(label_sz)
            ax.SetTitleSize(title_sz)
            ax.SetNdivisions(505)
            ax.SetAxisColor(ROOT.kBlack)
            try:
                ga = ax.GetAxis()
                if ga:
                    ga.SetLineWidth(axis_lw)
            except AttributeError:
                pass

        if small:
            f.GetXaxis().SetTitleOffset(style.get('inset_x_title_offset', 1.2))
            f.GetYaxis().SetTitleOffset(style.get('inset_y_title_offset', 2.2))
        else:
            f.GetXaxis().SetTitleOffset(style.get('x_title_offset', 1.2))
            f.GetYaxis().SetTitleOffset(style.get('y_title_offset', 1.2))
        keep.append(f)

        if bottom < 0 < top and style.get('draw_zero_line', True):
            line = ROOT.TLine(lo, 0, hi, 0)
            line.SetLineStyle(style.get('zero_line_style', 2))
            line.SetLineColor(get_root_constant(style.get('zero_line_color', 'kGray+1')))
            line.SetLineWidth(style.get('zero_line_width', 2))
            line.Draw()
            keep.append(line)
        return f

    def alice_syst(hist):
        if not syst_dict:
            return None
        b = MakeSystBoxFixedWidth(hist, syst_dict, half_width=half_width)
        b.SetFillStyle(0)
        b.SetLineColor(us_color)
        b.SetLineWidth(style.get('syst_linewidth', 3))
        b.SetMarkerSize(0)
        b.Draw('E2 SAME')
        keep.append(b)
        return b

    frame(main, f'frame_{key}', xmin, xmax, ymin, ymax)
    alice_syst(h_us)
    if g_star_syst:
        g_star_syst.SetFillStyle(0)
        g_star_syst.SetLineColor(star_color)
        g_star_syst.SetLineWidth(star_syst_linewidth)
        g_star_syst.Draw('E2 SAME')
    g_star.Draw('E1 P same')
    h_us.Draw(f"{style.get('drawopt', 'E')} SAME")
    main.RedrawAxis()

    # Enlarged ALICE view with matching axis titles.
    main.cd()
    zoom = ROOT.TPad(f'zoom_{key}', '', ic.get('x1', 0.43), ic.get('y1', 0.48),
                     ic.get('x2', 0.95), ic.get('y2', 0.94))
    zoom.SetFillStyle(1001)
    zoom.SetFillColor(ROOT.kWhite)
    zoom.SetFrameFillColor(ROOT.kWhite)
    zoom.SetBorderMode(0)
    zoom.SetLeftMargin(style.get('inset_left_margin', 0.24))
    zoom.SetRightMargin(0.04)
    zoom.SetBottomMargin(0.23)
    zoom.SetTopMargin(0.05)
    zoom.SetTicks(1, 1)
    zoom.Draw()
    zoom.cd()
    frame(zoom, f'zoom_frame_{key}', ic.get('xmin', 0.0), ic.get('xmax', 1.2),
          ic.get('ymin', -0.002), ic.get('ymax', 0.015), True)
    hu = h_us.Clone(f'{key}_zoom_data')
    hu.SetDirectory(0)
    hu.SetMarkerSize(ic.get('markersize', 1.5))
    hu.SetLineWidth(ic.get('linewidth', 2))
    alice_syst(hu)
    hu.Draw('E1 X0 SAME')
    zoom.RedrawAxis()
    keep += [zoom, hu]

    # ---- legend syst box helper ----
    def draw_legend_syst_box(legend, color, enabled, store=True):
        legend.SetMargin(0.25)
        if not enabled:
            return None
        info.Modified()
        info.Update()
        x1, x2 = legend.GetX1NDC(), legend.GetX2NDC()
        y1, y2 = legend.GetY1NDC(), legend.GetY2NDC()
        xc = x1 + 0.5 * legend.GetMargin() * (x2 - x1)
        yc = 0.5 * (y1 + y2)
        hw = style.get('legend_syst_half_width', 0.045)
        hh = style.get('legend_syst_half_height', 0.018)
        rect = ROOT.TBox(xc - hw, yc - hh, xc + hw, yc + hh)
        rect.SetFillStyle(0)
        rect.SetLineColor(color)
        rect.SetLineWidth(style.get('legend_syst_linewidth', 2))
        rect.Draw('same')
        if store:
            keep.append(rect)
        return rect

    # ---- information column ----
    info.cd()

    # 实验名 + 标题仍用 TLatex
    tx = ROOT.TLatex()
    tx.SetNDC(True)
    tx.SetTextFont(42)
    tx.SetTextColor(ROOT.kBlack)

    tx.SetTextSize(style.get('info_header_textsize', 0.06))
    tx.DrawLatex(0.035, 0.89, 'ALICE Preliminary')

    # ALICE legend
    leg = ROOT.TLegend(*alice_leg_box)
    leg.SetFillStyle(0)
    leg.SetBorderSize(0)
    leg.SetTextFont(42)
    leg.SetTextSize(LEG_SIZE)
    leg.AddEntry(h_us, '#Lambda#bar{#Lambda}', 'pe')
    leg.Draw()
    alice_box = draw_legend_syst_box(leg, us_color, bool(syst_dict))

    # 把 TLatex 文本转成 TMathText 语法
    def to_mathtext(s):
        s = s.replace('#Lambda', r'\Lambda')
        s = s.replace('#bar{#Lambda}', r'\bar{\Lambda}')
        s = s.replace('#it{', r'\mathit{')
        s = s.replace('#sqrt{', r'\sqrt{')
        s = s.replace('#it{s}', r'\mathit{s}')
        s = s.replace('#it{p}', r'\mathit{p}')
        s = s.replace('#it{y}', r'\mathit{y}')
        s = s.replace('#it{c}', r'\mathit{c}')
        s = s.replace('#theta', r'\theta')
        s = s.replace('#Delta', r'\Delta')
        s = s.replace('#eta', r'\eta')
        s = s.replace('#phi', r'\phi')
        s = s.replace('#langle', r'\langle')
        s = s.replace('#rangle', r'\rangle')
        s = s.replace('<p_{T,#Lambda}>',
                      r'\langle \mathit{p}_{T,\Lambda} \rangle')

        for word in ('GeV', 'TeV', 'MeV', 'pp', 'PbPb', 'ALICE', 'STAR'):
            s = s.replace(word, r'\mathrm{' + word + '}')

        return s

    tm = ROOT.TMathText()
    tm.SetNDC(True)
    tm.SetTextFont(42)
    tm.SetTextColor(ROOT.kBlack)
    tm.SetTextAlign(12)

    texts = style.get('latex', [])
    alice_lines, star_lines = [], []
    for item in texts:
        text = item[2]
        if 'Preliminary' in text:
            continue
        target = star_lines if ('STAR' in text or item[0] >= 0.5) else alice_lines
        clean = text.replace('ALICE:', '').replace('STAR:', '')
        if clean.startswith('|') and ', ' in clean:
            target.extend(clean.split(', '))
        else:
            target.append(clean)
    if not alice_lines:
        alice_lines = ['pp, #sqrt{#it{s}} = 13.6 TeV',
                       '|#it{y}| < 0.5', '0.6 < #it{p}_{T} < 3 GeV/#it{c}']

    def write_math_lines(lines, start):
        for j, text in enumerate(lines):
            tm.SetTextSize(style.get('info_text_textsize', 0.06))
            tm.DrawMathText(0.04, start - j * 0.065, to_mathtext(text))

    # ALICE 说明行
    write_math_lines(alice_lines, 0.70)

    # STAR 标题
    tx.SetTextSize(style.get('info_header_textsize', 0.06))
    tx.DrawLatex(0.035, 0.49, 'STAR')

    # STAR legend
    sl = ROOT.TLegend(*star_leg_box)
    sl.SetFillStyle(0)
    sl.SetBorderSize(0)
    sl.SetTextFont(42)
    sl.SetTextSize(LEG_SIZE)
    sl.AddEntry(g_star, '#Lambda#bar{#Lambda}', 'pe')
    sl.Draw()
    star_box = draw_legend_syst_box(sl, star_color, g_star_syst is not None)

    # STAR 说明行（含 \langle ... \rangle）
    write_math_lines(star_lines, 0.30)

    if style.get('star_reference'):
        tx.SetTextSize(style.get('info_ref_textsize', 0.06))
        tx.DrawLatex(0.04, 0.12, style['star_reference'])

    keep += [tx, tm, leg, sl]

    # ============================================================
    # 关键修复：先做完整的 canvas 级更新 + 审查，再对 info pad 做最终重绘
    # ============================================================
    c.cd()
    c.Modified()
    c.Update()

    # 先跑 enforce / review（它们会把图例字号改成 0.045，所以放到重绘之前）
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)

    # ---- 最终重绘 info pad：恢复字号 + 重画 legend/box，确保 PDF 可见 ----
    info.cd()
    # 清除并重建 info pad 内容（避免残留/覆盖问题）
    info.Clear()
    info.SetFillColor(ROOT.kWhite)
    info.SetBorderMode(0)
    info.Draw()

    # 重画 ALICE 标题
    tx.SetNDC(True)
    tx.SetTextFont(42)
    tx.SetTextColor(ROOT.kBlack)
    tx.SetTextSize(style.get('info_header_textsize', 0.06))
    tx.DrawLatex(0.035, 0.89, 'ALICE Preliminary')

    # 重画 ALICE legend
    leg.SetTextFont(42)
    leg.SetTextSize(LEG_SIZE)
    for entry in leg.GetListOfPrimitives():
        if entry.InheritsFrom('TLegendEntry'):
            entry.SetTextFont(42)
            entry.SetTextSize(LEG_SIZE)
    leg.Draw()
    alice_box_final = draw_legend_syst_box(leg, us_color, bool(syst_dict), store=False)

    # 重画 ALICE 说明行
    write_math_lines(alice_lines, 0.70)

    # 重画 STAR 标题
    tx.SetTextSize(style.get('info_header_textsize', 0.06))
    tx.DrawLatex(0.035, 0.49, 'STAR')

    # 重画 STAR legend
    sl.SetTextFont(42)
    sl.SetTextSize(LEG_SIZE)
    for entry in sl.GetListOfPrimitives():
        if entry.InheritsFrom('TLegendEntry'):
            entry.SetTextFont(42)
            entry.SetTextSize(LEG_SIZE)
    sl.Draw()
    star_box_final = draw_legend_syst_box(sl, star_color, g_star_syst is not None, store=False)

    # 重画 STAR 说明行
    write_math_lines(star_lines, 0.30)

    if style.get('star_reference'):
        tx.SetTextSize(style.get('info_ref_textsize', 0.06))
        tx.DrawLatex(0.04, 0.12, style['star_reference'])

    info.Modified()
    info.Update()

    # 回到主 canvas 并最终刷新所有 pad
    c.cd()
    c.Modified()
    c.Update()
    for pad in (main, zoom, info):
        pad.cd()
        pad.Modified()
        pad.Update()
    c.cd()
    c.Modified()
    c.Update()

    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")

def draw_ss_ratio_with_fit(key, style_key):
    """
    从 SS 的 SE / ME 两个 TH1D 现场算 ratio（各自归一化），
    用 Signal1d = 1 + CP*x 拟合，画图 + 写参数。
    """
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]

    # ---- 读 SE / ME ----
    inp_se = config['input']['hSE_SS_Rbin0']
    inp_me = config['input']['hME_SS_Rbin0']

    h_se, _ = LoadObjectFromFile(inp_se['file'], inp_se['object'])
    h_me, _ = LoadObjectFromFile(inp_me['file'], inp_me['object'])
    if not h_se or not h_me:
        raise RuntimeError("Cannot load SS SE/ME for ratio")

    h_se = h_se.Clone('h_se_ss_ratio_src'); h_se.SetDirectory(0)
    h_me = h_me.Clone('h_me_ss_ratio_src'); h_me.SetDirectory(0)

    # ---- 归一化 ----
    norm_mode = style.get('norm_mode', 'integral')

    def normalize(h):
        hh = h.Clone(h.GetName() + '_norm'); hh.SetDirectory(0)
        if norm_mode == 'none':
            return hh
        if norm_mode == 'mean':
            nb = hh.GetNbinsX()
            s, n = 0.0, 0
            for b in range(1, nb + 1):
                y = hh.GetBinContent(b)
                e = hh.GetBinError(b)
                if e > 0 and y > 0:
                    s += y; n += 1
            mean = s / n if n > 0 else 1.0
            if mean > 0:
                hh.Scale(1.0 / mean)
            return hh
        integ = hh.Integral()
        if integ > 0:
            hh.Scale(1.0 / integ)
        return hh

    h_se_n = normalize(h_se)
    h_me_n = normalize(h_me)

    # ---- ratio = SE / ME（bin by bin，误差用误差传播）----
    nb = h_se_n.GetNbinsX()
    h_ratio = h_se_n.Clone('hRatio_SS_Rbin0')
    h_ratio.SetDirectory(0)
    h_ratio.Reset()
    h_ratio.SetTitle('')

    for b in range(1, nb + 1):
        s = h_se_n.GetBinContent(b)
        es = h_se_n.GetBinError(b)
        m = h_me_n.GetBinContent(b)
        em = h_me_n.GetBinError(b)
        if m > 0 and s > 0:
            r = s / m
            er = r * ROOT.TMath.Sqrt((es/s)**2 + (em/m)**2)
            h_ratio.SetBinContent(b, r)
            h_ratio.SetBinError(b, er)
        else:
            h_ratio.SetBinContent(b, 0.0)
            h_ratio.SetBinError(b, 0.0)

    # ---- 样式 ----
    col = get_root_constant(style.get('linecolor', 'kBlack'))
    h_ratio.SetLineColor(col)
    h_ratio.SetMarkerColor(col)
    h_ratio.SetMarkerStyle(get_root_constant(style.get('markerstyle', 'kFullCircle')))
    h_ratio.SetMarkerSize(style.get('markersize', 3.0))
    h_ratio.SetLineWidth(style.get('linewidth', 5))

    parts = style.get('axisname', ';;').split(';')
    if len(parts) >= 2: h_ratio.GetXaxis().SetTitle(parts[1])
    if len(parts) >= 3: h_ratio.GetYaxis().SetTitle(parts[2])

    xmin = style.get('xmin', -1.0)
    xmax = style.get('xmax',  1.0)
    ymin = style.get('ymin', None)
    ymax = style.get('ymax', -1)

    if ymax < 0:
        ymax_auto = 0.0
        for b in range(1, nb + 1):
            y = h_ratio.GetBinContent(b)
            e = h_ratio.GetBinError(b)
            if not (y == 0 and e == 0):
                ymax_auto = max(ymax_auto, y + e)
        ymax = ymax_auto * style.get('yrange_scale', 1.4)
    if ymin is None:
        ymin = 0.96

    h_ratio.GetXaxis().SetRangeUser(xmin, xmax)
    h_ratio.GetYaxis().SetRangeUser(ymin, ymax)

    # ---- canvas ----
    c, hframe = GetCanvas(
        f'c_{key}', style.get('axisname', ';;'),
        xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax,
        setlogx=style.get('setlogx', False),
        setlogy=style.get('setlogy', False)
    )

    n_div_x = style.get('ndiv_x', 4)
    n_div_y = style.get('ndiv_y', 4)
    hframe.GetXaxis().SetNdivisions(n_div_x, False)
    hframe.GetYaxis().SetNdivisions(n_div_y, False)

    # ---- y/x 轴标题离轴距离 ----
    hframe.GetXaxis().SetTitleOffset(style.get('x_title_offset', 1.2))
    hframe.GetYaxis().SetTitleOffset(style.get('y_title_offset', 2.0))

    c.cd()
    hframe.Draw('AXIS')
    h_ratio.Draw(f"{style.get('drawopt', 'E')} SAME")

    # ---- 用 Signal1d 拟合（范围 -1..1）----
    fit_xmin = style.get('fit_xmin', -1.0)
    fit_xmax = style.get('fit_xmax',  1.0)
    cscale   = style.get('cscale', 1.0)

    fit_func = ROOT.TF1(f'tf1_fit_SS_{key}', '1.0 + [0]*x', fit_xmin, fit_xmax)
    fit_func.SetParameter(0, 0.0)
    fit_func.SetParLimits(0, -1.0, 1.0)
    fit_func.SetLineColor(get_root_constant(style.get('fit_color', 'kRed')))
    fit_func.SetLineWidth(style.get('fit_linewidth', 3))
    fit_func.SetLineStyle(style.get('fit_linestyle', 1))

    fit_status = h_ratio.Fit(fit_func, 'EIRMBS', '', fit_xmin, fit_xmax)

    cp     = fit_func.GetParameter(0)
    cp_err = fit_func.GetParError(0)
    ndf    = fit_func.GetNDF()
    chi2   = fit_func.GetChisquare()
    chi2ndf = (chi2 / ndf) if ndf > 0 else 0.0

    if cscale != 0.0:
        P     = cp / cscale
        P_err = cp_err / abs(cscale)
    else:
        P, P_err = 0.0, 0.0

    print(f"[SS ratio fit] key={key} status={fit_status} CP={cp:.5f}±{cp_err:.5f} "
          f"chi2/ndf={chi2:.2f}/{ndf}={chi2ndf:.3f} P={P:.4f}±{P_err:.4f}")

    fit_func.Draw('SAME')

    # ---- 参考线 ----
    if style.get('draw_one_line', False):
        line = ROOT.TLine(xmin, 1.0, xmax, 1.0)
        line.SetLineStyle(2)
        line.SetLineColor(ROOT.kGray + 1)
        line.SetLineWidth(2)
        line.Draw('SAME')

    # ---- 图例 ----
    if style.get('legend'):
        lg = style['legend']
        leg = GetLegend(
            xmin=lg.get('xmin', 0.55),
            ymin=lg.get('ymin', 0.70),
            xmax=lg.get('xmax', 0.88),
            ymax=lg.get('ymax', 0.88),
            textsize=0.045,
            ncolumns=lg.get('ncolumns', 1),
            header=lg.get('header', '')
        )
        leg.AddEntry(h_ratio, lg.get('label_data', 'Data'), 'p')
        leg.AddEntry(fit_func, lg.get('label_fit', 'Fit (1 + #alpha_{1}#alpha_{2} #it{P} cos(#it{#theta}^{*}))'), 'l')
        leg.Draw('same')

    # ---- latex ----
    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    # ---- 拟合公式 ----
    formula = ROOT.TLatex()
    formula.SetNDC()
    formula.SetTextFont(42)
    formula.SetTextSize(style.get('formula_textsize', 0.035))
    formula.SetTextColor(ROOT.kBlack)


    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")


# ------------------------------------------------------------------
# 4b-4. Helper: 画一个 ΔP TH1D（LAL 或 SS）
# ------------------------------------------------------------------
def draw_deltaP(key, style_key):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]
    inp = config['input'][key]

    h, _ = LoadObjectFromFile(inp['file'], inp['object'])
    if not h:
        raise RuntimeError(f"Cannot load {key}")

    # ---- style ----
    col = get_root_constant(style.get('linecolor',  'kBlack'))
    h.SetLineColor(col)
    h.SetMarkerColor(col)
    h.SetMarkerStyle(get_root_constant(style.get('markerstyle', 'kFullCircle')))
    h.SetMarkerSize(style.get('markersize', 3.0))
    h.SetLineWidth(style.get('linewidth', 5))

    # ---- axis title ----
    parts = style.get('axisname', ';;').split(';')
    if len(parts) >= 2:
        h.GetXaxis().SetTitle(parts[1])
    if len(parts) >= 3:
        h.GetYaxis().SetTitle(parts[2])

    # ---- x/y range ----
    xmin = style.get('xmin', h.GetXaxis().GetXmin())
    xmax = style.get('xmax', h.GetXaxis().GetXmax())
    ymin = style.get('ymin', None)
    ymax = style.get('ymax', -1)

    if ymax < 0:
        ymax_auto = 0.0
        ymin_auto = 0.0
        for i in range(1, h.GetNbinsX() + 1):
            y = h.GetBinContent(i)
            e = h.GetBinError(i)
            if not (y == 0 and e == 0):       # 跳过无效 bin
                ymax_auto = max(ymax_auto, y + e)
                ymin_auto = min(ymin_auto, y - e)
        if ymax_auto == 0.0 and ymin_auto == 0.0:
            ymin_auto, ymax_auto = -0.005, 0.005
        span = max(1e-6, ymax_auto - ymin_auto)
        ymin = ymin_auto - 0.2 * span
        ymax = ymax_auto + 0.2 * span

    if ymin is None:
        ymin = 0.0

    h.GetXaxis().SetRangeUser(xmin, xmax)
    h.GetYaxis().SetRangeUser(ymin, ymax)

    # ---- canvas ----
    c, hframe = GetCanvas(
        f'c_{key}', style.get('axisname', ';;'),
        xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax,
        setlogx=style.get('setlogx', False),
        setlogy=style.get('setlogy', False)
    )

    n_div_x = style.get('ndiv_x', 4)
    n_div_y = style.get('ndiv_y', 4)
    hframe.GetXaxis().SetNdivisions(n_div_x, False)
    hframe.GetYaxis().SetNdivisions(n_div_y, False)

    # ---- data points ----
    h.GetYaxis().SetRangeUser(ymin, ymax)
    h.Draw(f"{style.get('drawopt', 'E')} SAME")

    # ---- zero line ----
    if style.get('draw_zero_line', False):
        line = ROOT.TLine(xmin, 0.0, xmax, 0.0)
        line.SetLineStyle(style.get('zero_line_style', 2))
        line.SetLineColor(get_root_constant(style.get('zero_line_color', 'kGray+1')))
        line.SetLineWidth(style.get('zero_line_width', 2))
        line.Draw('SAME')

    # ---- legend ----
    if style.get('legend'):
        lg = style['legend']
        leg = GetLegend(
            xmin=lg.get('xmin', 0.60),
            ymin=lg.get('ymin', 0.75),
            xmax=lg.get('xmax', 0.90),
            ymax=lg.get('ymax', 0.88),
            textsize=0.045,
            ncolumns=lg.get('ncolumns', 1),
            header=lg.get('header', '')
        )
        h_leg = create_legend_clone(h)
        leg.AddEntry(h_leg, '#DeltaP', 'p')
        leg.Draw('same')

    # ---- latex ----
    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    latex.SetNDC();
    latex.SetTextSize(0.03);
    latex.DrawLatex(0.20, 0.15, "With and witout signal fraction");

    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")


# ------------------------------------------------------------------
# 4c-2. Helper: 只画 m_Λ1 数据点（带误差棒），不画任何拟合曲线
# ------------------------------------------------------------------
def draw_extracted_cSE_data_only(key, style_key):
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]

    inp_file = style.get('input_file')
    prefix   = style.get('prefix', 'c_SE_R0_c01')

    # ---- 只读数据点 ----
    f_in = ROOT.TFile.Open(inp_file, 'READ')
    if not f_in or f_in.IsZombie():
        raise RuntimeError(f"Cannot open {inp_file}")

    g_data = f_in.Get(f'{prefix}_datax')
    if not g_data:
        f_in.Close()
        raise RuntimeError(f"Cannot find {prefix}_datax in {inp_file}")
        g_data = g_data.Clone(f'{key}_data_clone')
    try:
        g_data.SetDirectory(0)
    except AttributeError:
        pass
    f_in.Close()

    # ---- 样式 ----
    col_data = get_root_constant(style.get('color_data', 'kBlack'))
    mk_data  = get_root_constant(style.get('marker_data', 'kFullCircle'))
    ms_data  = style.get('markersize_data', 2.0)
    lw_data  = style.get('linewidth_data', 2)

    g_data.SetMarkerStyle(mk_data)
    g_data.SetMarkerSize(ms_data)
    g_data.SetMarkerColor(col_data)
    g_data.SetLineColor(col_data)
    g_data.SetLineWidth(lw_data)

    # ---- x/y range ----
    xmin = style.get('xmin', 1.095)
    xmax = style.get('xmax', 1.135)
    ymin = style.get('ymin', None)
    ymax = style.get('ymax', -1)

    if ymax < 0:
        ymax_auto = 0.0
        for i in range(g_data.GetN()):
            y  = g_data.GetY()[i]
            ey = g_data.GetEY()[i] if isinstance(g_data, ROOT.TGraphErrors) else 0.0
            ymax_auto = max(ymax_auto, y + ey)
        ymax = ymax_auto * style.get('yrange_scale', 1.35)
    if ymin is None:
        ymin = 0.0

    # ---- canvas ----
    c = ROOT.TCanvas(f'c_{key}', f'c_{key}', 1600, 1600)
    gs = config.get('global_style', {})
    c.SetLeftMargin(gs.get('padleftmargin', 0.14))
    c.SetRightMargin(gs.get('padrightmargin', 0.04))
    c.SetTopMargin(gs.get('padtopmargin', 0.08))
    c.SetBottomMargin(gs.get('padbottommargin', 0.12))

    if style.get('setlogx', False):
        c.SetLogx()
    if style.get('setlogy', False):
        c.SetLogy()

    # 框架 + 数据点（带误差棒）
    h_frame = g_data.Clone(f'{key}_frame')
    h_frame.SetTitle('')
    h_frame.GetXaxis().SetRangeUser(xmin, xmax)
    h_frame.GetYaxis().SetRangeUser(ymin, ymax)
    h_frame.GetXaxis().SetTitle('#it{M}_{p#pi^{-}} (GeV/#it{c}^{2})')
    h_frame.GetYaxis().SetTitle('Counts/ 1.0 MeV/#it{c}^{2}')
    h_frame.GetYaxis().SetTitleOffset(2.0)
    h_frame.GetXaxis().SetTitleOffset(1.2)
    h_frame.Draw('AP')

    g_data.Draw('PE SAME')

    # ---- legend ----
    if style.get('legend'):
        lg = style['legend']
        leg = GetLegend(
            xmin=lg.get('xmin', 0.75),
            ymin=lg.get('ymin', 0.55),
            xmax=lg.get('xmax', 0.98),
            ymax=lg.get('ymax', 0.88),
            textsize=0.045,
            ncolumns=lg.get('ncolumns', 1),
            header=lg.get('header', '')
        )
        g_leg = g_data.Clone(f'{key}_data_leg')
        g_leg.SetMarkerStyle(g_data.GetMarkerStyle())
        g_leg.SetMarkerColor(g_data.GetMarkerColor())
        g_leg.SetMarkerSize(g_data.GetMarkerSize())
        g_leg.SetLineColor(g_data.GetLineColor())
        g_leg.SetLineWidth(g_data.GetLineWidth())
        leg.AddEntry(g_leg, lg.get('label_data', 'Data'), 'pe')
        leg.Draw('same')

    # ---- latex ----
    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")

def draw_ss_ratio(key, style_key):
    """
    从 SS 的 SE / ME 现场算 ratio（各自归一化），
    按 hRatio_Rbin0_style 的风格画点（不拟合）。
    """
    if not config.get(f'plot_{key}', False):
        return

    style = config[style_key]

    # ---- 读 SS 的 SE / ME ----
    inp_se = config['input']['hSE_SS_Rbin0']
    inp_me = config['input']['hME_SS_Rbin0']
    h_se, _ = LoadObjectFromFile(inp_se['file'], inp_se['object'])
    h_me, _ = LoadObjectFromFile(inp_me['file'], inp_me['object'])
    if not h_se or not h_me:
        raise RuntimeError("Cannot load SS SE/ME for ratio")

    h_se = h_se.Clone('h_se_ss_ratio_plain'); h_se.SetDirectory(0)
    h_me = h_me.Clone('h_me_ss_ratio_plain'); h_me.SetDirectory(0)

    # ---- 归一化 ----
    norm_mode = style.get('norm_mode', 'integral')

    def normalize(h):
        hh = h.Clone(h.GetName() + '_n'); hh.SetDirectory(0)
        if norm_mode == 'none':
            return hh
        if norm_mode == 'mean':
            s, n = 0.0, 0
            for b in range(1, hh.GetNbinsX() + 1):
                y, e = hh.GetBinContent(b), hh.GetBinError(b)
                if e > 0 and y > 0:
                    s += y; n += 1
            if n > 0 and s > 0:
                hh.Scale(1.0 / (s / n))
            return hh
        integ = hh.Integral()
        if integ > 0:
            hh.Scale(1.0 / integ)
        return hh

    h_se_n = normalize(h_se)
    h_me_n = normalize(h_me)

    # ---- ratio = SE/ME，误差传播 ----
    nb = h_se_n.GetNbinsX()
    h_ratio = h_se_n.Clone(f'{key}_ratio')
    h_ratio.SetDirectory(0)
    h_ratio.Reset()
    h_ratio.SetTitle('')

    for b in range(1, nb + 1):
        s  = h_se_n.GetBinContent(b); es = h_se_n.GetBinError(b)
        m  = h_me_n.GetBinContent(b); em = h_me_n.GetBinError(b)
        if m > 0 and s > 0:
            r  = s / m
            er = r * ROOT.TMath.Sqrt((es/s)**2 + (em/m)**2)
            h_ratio.SetBinContent(b, r)
            h_ratio.SetBinError(b, er)
        else:
            h_ratio.SetBinContent(b, 0.0)
            h_ratio.SetBinError(b, 0.0)

    # ---- 样式（与 hRatio_Rbin0_style 一致）----
    col = get_root_constant(style.get('linecolor', 'kBlack+1'))
    h_ratio.SetLineColor(col)
    h_ratio.SetMarkerColor(col)
    h_ratio.SetMarkerStyle(get_root_constant(style.get('markerstyle', 'kFullCircle')))
    h_ratio.SetMarkerSize(style.get('markersize', 3.0))
    h_ratio.SetLineWidth(style.get('linewidth', 5))

    parts = style.get('axisname', ';;').split(';')
    if len(parts) >= 2: h_ratio.GetXaxis().SetTitle(parts[1])
    if len(parts) >= 3: h_ratio.GetYaxis().SetTitle(parts[2])

    xmin = style.get('xmin', -1.0)
    xmax = style.get('xmax',  1.0)
    ymin = style.get('ymin', 0.96)
    ymax = style.get('ymax', 1.1)

    h_ratio.GetXaxis().SetRangeUser(xmin, xmax)
    h_ratio.GetYaxis().SetRangeUser(ymin, ymax)

    # ---- canvas ----
    c, hframe = GetCanvas(
        f'c_{key}', style.get('axisname', ';;'),
        xmin=xmin, xmax=xmax, ymin=ymin, ymax=ymax,
        setlogx=style.get('setlogx', False),
        setlogy=style.get('setlogy', False)
    )

    n_div_x = style.get('ndiv_x', 4)
    n_div_y = style.get('ndiv_y', 4)
    hframe.GetXaxis().SetNdivisions(n_div_x, False)
    hframe.GetYaxis().SetNdivisions(n_div_y, False)
    hframe.GetYaxis().SetNoExponent(False)
    hframe.GetYaxis().SetMaxDigits(2)

    c.cd()
    hframe.Draw('AXIS')
    h_ratio.Draw(f"{style.get('drawopt', 'E')} SAME")

    # ---- latex ----
    for text in style.get('latex', []):
        latex.SetTextSize(text[-1])
        latex.DrawLatexNDC(text[0], text[1], text[2])

    c.Update()
    enforce_tick_and_legend_sizes(c)
    apply_review_layout(c, style)
    apply_second_review(c, style)
    SaveCanvas(c, f'{outdir}{key}', f'_{suffix}' if suffix else '', formats=formats)
    print(f"Saved {outdir}{key}")
# ------------------------------------------------------------------
# 5. Generate all requested plots
# ------------------------------------------------------------------
draw_abcd_2d('hABCD_SE_R0_c01', 'hABCD_SE_R0_c01_style')
draw_extracted_cSE_data_only('hP_extracted_cSE_data_only',
                             'hP_extracted_cSE_data_only_style') 
draw_th1d('hP_US_vsR', 'hP_US_vsR_style')
draw_th1d('hP_SS_vsR', 'hP_SS_vsR_style')

draw_thSEandME('hSE_fsScaled', 'hSE_fsScaled_style')
draw_thSEandME('hME_fsScaled', 'hME_fsScaled_style')
draw_thSEandME('hRatio_Rbin0', 'hRatio_Rbin0_style')

draw_deltaP('hDeltaP_LAL', 'hDeltaP_LAL_style')   
draw_deltaP('hDeltaP_SS',  'hDeltaP_SS_style') 

draw_ratio_with_fit('hRatio_with_fit', 'hRatio_with_fit_style')

draw_two_th1d(
    'hP_USSS_vsR',
    'hP_USSS_vsR_style',
    [
        {'input_key': 'hP_US_vsR',
         'label': '#Lambda#bar{#Lambda} + #bar{#Lambda}#Lambda',
         'color': 'kBlue+3', 'marker': 'kFullCircle',
         'markersize': 3.0},
        {'input_key': 'hP_SS_vsR',
         'label': '#Lambda#Lambda + #bar{#Lambda}#bar{#Lambda}',
         'color': 'kRed+1', 'marker': 'kFullSquare',
         'markersize': 3.0},
    ]
)

draw_us_with_models('hP_US_with_models', 'hP_US_with_models_style')
draw_us_with_star('hP_US_vsSTAR', 'hP_US_vsSTAR_style')
draw_se_me_sigfrac('hSigFrac_SE_ME_Rbin0', 'hSigFrac_SE_ME_Rbin0_style') 
draw_se_me_sigfrac('hSigFrac_SE_ME_Rbin0_SS', 'hSigFrac_SE_ME_Rbin0_SS_style')
draw_extracted_cSE('hP_extracted_cSE', 'hP_extracted_cSE_style')

draw_extracted_cSE_mLambda2('hP_extracted_cSE_mLambda2', 'hP_extracted_cSE_Lambda2_style')
draw_us_with_star_inset('hP_US_vsSTAR_inset', 'hP_US_vsSTAR_inset_style')
draw_thSEandME('hSE_SS_Rbin0', 'hSE_SS_Rbin0_style')
draw_thSEandME('hME_SS_Rbin0', 'hME_SS_Rbin0_style')

draw_ss_ratio_with_fit('hRatio_SS_Rbin0', 'hRatio_SS_Rbin0_style')
draw_ss_ratio('hRatio_SS_Rbin0_plain', 'hRatio_SS_Rbin0_plain_style')

# ------------------------------------------------------------------
# 6. Zip output
# ------------------------------------------------------------------
if config.get('zipfiles', False):
    zip_path = f'{outdir}figures_{suffix}.zip' if suffix else f'{outdir}figures.zip'
    with zipfile.ZipFile(zip_path, 'w') as zipf:
        for fmt in formats:
            for fname in os.listdir(outdir):
                if fname.endswith(fmt) and (not suffix or suffix in fname):
                    zipf.write(os.path.join(outdir, fname), arcname=fname)
    print(f"Wrote {zip_path}")

print("Done.")
