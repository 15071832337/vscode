// extract_cSE.C
#include <functional>
#include <TSystem.h>
#include <TFile.h>
#include <TCanvas.h>
#include <TPad.h>
#include <TH1.h>
#include <TGraph.h>
#include <TGraphErrors.h>
#include <TList.h>
#include <TIterator.h>
#include <TObject.h>
#include <TF1.h>
#include <RooHist.h>
#include <RooCurve.h>



void extract_cSE(const char* fname,
                 const char* cname,
                 const char* outDir = "/home/suyoupeng/Downloads/lambdaspincorefile/Local_O2update/drawPicturecode/figures/MassFitpicture")
{
    TFile* f = TFile::Open(fname, "READ");
    if (!f || f->IsZombie()) { printf("ERROR: cannot open %s\n", fname); return; }

    TCanvas* c = (TCanvas*)f->Get(cname);
    if (!c) { printf("ERROR: cannot find canvas %s\n", cname); f->Close(); return; }

    gSystem->mkdir(outDir, kTRUE);

    TString out = Form("%s/%s_extracted.root", outDir, cname);
    TFile* fout = TFile::Open(out, "RECREATE");
    if (!fout || fout->IsZombie()) {
        printf("ERROR: cannot create %s\n", out.Data());
        f->Close(); return;
    }

    // 把任意 TObject 转成 TGraphErrors 并写入 fout
    auto saveObj = [&](TObject* q, const TString& prefix) {
        if (!q) return;
        TString cls = q->ClassName();
        TString nm  = q->GetName();
        TGraphErrors* g = nullptr;

        if (cls == "RooHist") {
            RooHist* h = (RooHist*)q;
            const int n = h->GetN();
            g = new TGraphErrors(n);
            for (int i = 0; i < n; ++i) {
                double x, y;
                h->GetPoint(i, x, y);
                double ex = 0.5 * (h->GetErrorXlow(i)  + h->GetErrorXhigh(i));
                double ey = 0.5 * (h->GetErrorYlow(i)  + h->GetErrorYhigh(i));
                g->SetPoint(i, x, y);
                g->SetPointError(i, ex, ey);
            }
        }
        else if (cls == "RooCurve") {
            RooCurve* cu = (RooCurve*)q;
            const int n = cu->GetN();
            g = new TGraphErrors(n);
            for (int i = 0; i < n; ++i) {
                double x, y;
                cu->GetPoint(i, x, y);
                g->SetPoint(i, x, y);
                g->SetPointError(i, 0.0, 0.0);
            }
        }
        else if (cls == "TF1") {
            TF1* fn = (TF1*)q;
            const int n = 500;
            double xmin = fn->GetXmin(), xmax = fn->GetXmax();
            g = new TGraphErrors(n + 1);
            for (int i = 0; i <= n; ++i) {
                double x = xmin + (xmax - xmin) * i / n;
                g->SetPoint(i, x, fn->Eval(x));
                g->SetPointError(i, 0.0, 0.0);
            }
        }
        else if (cls == "TGraphErrors" || cls == "TGraph") {
            TGraph* g0 = (TGraph*)q;
            const int n = g0->GetN();
            g = new TGraphErrors(n);
            for (int i = 0; i < n; ++i) {
                double x, y;
                g0->GetPoint(i, x, y);
                double ex = 0, ey = 0;
                if (g0->InheritsFrom("TGraphErrors")) {
                    ex = ((TGraphErrors*)g0)->GetErrorX(i);
                    ey = ((TGraphErrors*)g0)->GetErrorY(i);
                }
                g->SetPoint(i, x, y);
                g->SetPointError(i, ex, ey);
            }
        }

        if (g) {
            g->SetName(Form("%s_%s", prefix.Data(), nm.Data()));
            g->SetTitle(nm.Data());
            fout->cd();
            g->Write();
            printf("  [%s] %s  N=%d\n", cls.Data(), g->GetName(), g->GetN());
        }
    };

    // 递归遍历 pad
    std::function<void(TPad*, const TString&)> walk = [&](TPad* pad, const TString& prefix) {
        if (!pad) return;

        // ---- 1) 如果 frame 是 RooPlot，用 getHist()->GetListOfFunctions() ----
        if (TFrame* frame = pad->GetFrame()) {
            if (RooPlot* rp = dynamic_cast<RooPlot*>(frame)) {
                RooHist* rh = rp->getHist();              // ← RooHist*
                if (rh) {
                    TList* funcs = rh->GetListOfFunctions();   // ← 在 RooHist 上
                    if (funcs) {
                        TIter itf(funcs);
                        TObject* q = nullptr;
                        while ((q = itf())) saveObj(q, prefix);
                    }
                }
            }
        }

        // ---- 2) 遍历 pad 自己的 primitives ----
        TIter itp(pad->GetListOfPrimitives());
        TObject* p = nullptr;
        while ((p = itp())) {
            TString cls = p->ClassName();

            if (cls == "TPad") {
                walk((TPad*)p, prefix);          // 递归子 pad
            } else {
                saveObj(p, prefix);              // RooCurve / RooHist / TGraph / TF1 ...
            }
        }
    };

    walk(c, cname);

    fout->Write();
    fout->Close();
    f->Close();
    printf("Saved to %s\n", out.Data());
}



void run()
{
    extract_cSE(
      "/home/suyoupeng/Downloads/lambdaspincorefile/Analysiscode/Sourav_code/LHC26Analysis_V6_true_local/Output_pp_sig0_bkg2_hSparseLambdaAntiLambda/fit_Rbin0.root",
      "c_SE_R0_c01"
    );
}